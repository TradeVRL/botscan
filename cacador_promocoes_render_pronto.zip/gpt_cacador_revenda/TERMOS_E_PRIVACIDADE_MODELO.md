# Modelo inicial de termos e privacidade

Este arquivo é apenas um roteiro operacional e não substitui revisão jurídica.

## Pontos que os termos devem cobrir

- Identificação da empresa responsável pelo serviço.
- Descrição do serviço e dos planos.
- Quantidade de pesquisas, validade, renovação e cancelamento.
- Ausência de garantia de preço, estoque, venda, margem ou lucro.
- Responsabilidade do cliente por confirmar produto, fornecedor, tributos e regras dos marketplaces.
- Proibição de uso para produtos ilegais, falsificados, perigosos ou restritos.
- Regras de suspensão por abuso, fraude, compartilhamento indevido ou tentativa de obter segredos do sistema.
- Política de suporte, reembolso e indisponibilidade.
- Propriedade intelectual do software, relatórios e marca.

## Pontos que a política de privacidade deve cobrir

- Dados do Telegram tratados: ID, username, nome e mensagens enviadas ao bot.
- Dados de assinatura, plano, consumo e histórico das pesquisas.
- Compartilhamento necessário com infraestrutura, banco de dados e provedor de IA.
- Prazo de retenção e processo de exclusão.
- Medidas de segurança e canais de atendimento.
- Base e finalidade do tratamento definidas pelo responsável jurídico.
- Procedimento para solicitações do titular.

Antes do lançamento comercial, substitua este roteiro por documentos completos com razão social, CNPJ, endereço, contato e regras reais da operação.
