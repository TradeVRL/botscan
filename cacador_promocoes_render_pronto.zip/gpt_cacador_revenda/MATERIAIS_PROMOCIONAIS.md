# Materiais promocionais prontos

Substitua `@SEU_BOT` pelo usuário real do bot.

## 1. Mensagem principal para WhatsApp

🔥 **Antes de comprar, pesquise no Caçador de Promoções**

O bot compara preços na internet, verifica se o desconto é real, considera o frete para o seu CEP e entrega os links das melhores ofertas.

Você pode pesquisar pelo nome do produto, enviar um link ou até uma foto da promoção.

🆓 20 consultas gratuitas por mês  
📍 Frete considerado pelo CEP  
🏷️ Busca de cupons e descontos  
🛒 Links diretos para os produtos

Acesse no Telegram: `https://t.me/SEU_BOT`

## 2. Mensagem curta para WhatsApp

🔥 Quer saber se uma promoção realmente vale a pena?

O Caçador de Promoções compara preços, considera o frete pelo CEP e mostra links diretos das ofertas.

🆓 20 consultas grátis por mês.

`https://t.me/SEU_BOT`

## 3. Status do WhatsApp

**Tela 1**  
Vai comprar alguma coisa? Não confie apenas no desconto anunciado.

**Tela 2**  
O Caçador de Promoções compara preços e considera o frete para seu CEP.

**Tela 3**  
🆓 20 consultas grátis por mês  
Acesse: `@SEU_BOT`

## 4. Post para Instagram

🔥 **A promoção é real ou só parece boa?**

O Caçador de Promoções pesquisa o produto na internet, compara anúncios equivalentes, considera o frete para o seu CEP e mostra os links das melhores ofertas.

Você pode enviar:

🔎 nome do produto  
🔗 link da oferta  
📷 foto ou print  
🏷️ pedido de cupom

🆓 São 20 consultas gratuitas por mês.

Acesse pelo link da bio ou procure `@SEU_BOT` no Telegram.

#promocao #desconto #cupom #ofertas #economia #telegrambot

## 5. Post para Instagram focado no Premium

💎 **Para quem pesquisa muito ou trabalha com revenda**

O Premium do Caçador de Promoções libera consultas ilimitadas e ferramentas avançadas para analisar:

📦 produtos para revenda  
🏪 fornecedores e atacadistas  
📊 Amazon, Mercado Livre e Shopee  
💰 lucro líquido, margem e ROI  
⚖️ ponto de equilíbrio  
📉 cenários de risco

Tudo por **R$ 9,90 a cada 30 dias**, sem fidelidade.

Acesse `@SEU_BOT` no Telegram.

## 6. Roteiro para Reel de 20 segundos

**Cena 1, 0 a 4 segundos**  
Mostrar um anúncio com desconto.

Texto na tela: “Essa promoção vale a pena?”

**Cena 2, 4 a 8 segundos**  
Abrir o Telegram e tocar em “Buscar produto”.

Narração: “Enviei o produto para o Caçador de Promoções.”

**Cena 3, 8 a 14 segundos**  
Mostrar preço, mediana, frete e economia.

Narração: “Ele comparou os preços e considerou o frete para o meu CEP.”

**Cena 4, 14 a 18 segundos**  
Mostrar os botões diretos das lojas.

Narração: “E ainda entregou os links das melhores ofertas.”

**Cena 5, 18 a 20 segundos**  
Tela com chamada.

Texto: “20 consultas grátis por mês • @SEU_BOT”

## 7. Roteiro para Reel: falso desconto

**Abertura**  
“Nem todo desconto de 40% é uma promoção de verdade.”

**Desenvolvimento**  
Mostrar o produto anunciado e depois a análise do bot com preço mediano próximo ao preço promocional.

**Fechamento**  
“Antes de comprar, consulte o Caçador de Promoções. São 20 pesquisas gratuitas por mês.”

## 8. Stories com enquete

**Story 1**  
Você confere o preço em outras lojas antes de comprar?

Enquete: `Sempre` | `Quase nunca`

**Story 2**  
Esse bot compara preços e considera o frete para seu CEP.

**Story 3**  
🆓 20 consultas gratuitas por mês  
Botão/link: `Abrir no Telegram`

## 9. Publicação para canal do Telegram

🔥 **OFERTA ANALISADA HOJE**

📦 [Nome do produto]  
💵 Oferta: [preço]  
📊 Mediana pesquisada: [preço]  
📉 Economia estimada: [valor]  
⭐ Avaliação: [excelente/boa]

Quer pesquisar outro produto e calcular o frete para o seu CEP?

🆓 Faça 20 consultas grátis no `@SEU_BOT`.

## 10. Mensagem de convite individual

Oi! Estou lançando um bot no Telegram que pesquisa promoções, compara preços e considera o frete para o CEP da pessoa.

Você pode testar gratuitamente e fazer até 20 consultas por mês. Gostaria muito que usasse e me dissesse se o resultado foi útil:

`https://t.me/SEU_BOT`

## 11. Mensagem para grupos de empreendedores

🧰 **Ferramenta para quem vende na internet**

O Caçador de Promoções possui uma área Premium para analisar oportunidades de revenda na Amazon, Mercado Livre e Shopee.

Ele pesquisa fornecedores, compara preços e estima lucro líquido, margem, ROI e ponto de equilíbrio.

💎 Premium ilimitado: R$ 9,90 por 30 dias.

Acesso: `https://t.me/SEU_BOT`

## 12. Texto para página de vendas

### Pesquise antes de comprar

O Caçador de Promoções compara preços na internet, verifica se o desconto é real, considera o frete para o seu CEP e mostra links diretos para as melhores ofertas encontradas.

### Comece gratuitamente

Faça até 20 consultas mensais sem pagar. Pesquise pelo nome, envie um link ou analise uma foto da promoção.

### Precisa de mais?

Ative o Premium por R$ 9,90 a cada 30 dias e tenha consultas ilimitadas, análises profundas e ferramentas para revenda.

**Chamada do botão:** `Abrir o bot gratuitamente`

## 13. Respostas rápidas para dúvidas

**É realmente gratuito?**  
Sim. O plano gratuito oferece 20 consultas por mês.

**Preciso instalar outro aplicativo?**  
Não. O serviço funciona dentro do Telegram.

**O bot compra o produto por mim?**  
Não. Ele pesquisa e apresenta links para você decidir e comprar diretamente na loja.

**O frete é garantido?**  
Algumas lojas só confirmam o frete no carrinho. Nesses casos, o bot informa que o valor precisa ser confirmado.

**O Premium tem fidelidade?**  
Não. O acesso custa R$ 9,90 por 30 dias.

**O Premium é ilimitado?**  
Sim, para uso individual e normal. Automação, compartilhamento de acesso e uso abusivo não são permitidos.

## 14. Frases curtas para artes

- Antes de comprar, pesquise.
- O desconto é real?
- Compare preços em segundos pelo Telegram.
- Frete considerado para o seu CEP.
- 20 consultas grátis por mês.
- Links diretos para as melhores ofertas.
- Premium ilimitado por R$ 9,90.
- Uma boa economia pode pagar vários meses do Premium.
