from secrets import choice
from string import ascii_letters, digits

alphabet = ascii_letters + digits + "_-"
print("".join(choice(alphabet) for _ in range(64)))
