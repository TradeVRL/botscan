# Atualizações desta versão

- Plano Gratuito alterado para 20 consultas mensais.
- Premium alterado para R$ 9,90 por 30 dias.
- Premium configurado com consultas ilimitadas para uso individual.
- Menu público reduzido a `/start` e `/menu`; navegação normal por botões.
- Pesquisa iniciada diretamente após escolha de categoria ou envio do produto.
- Resultados transformam links diretos em botões do Telegram.
- Botões de nova pesquisa, menu, Premium e compartilhamento após o relatório.
- Botão de compartilhamento configurável por `TELEGRAM_BOT_USERNAME`.
- Histórico ampliado para assinantes Premium.
- Mensagens de conversão quando restarem poucas consultas gratuitas.
- Migração lógica de usuários básicos com franquias antigas e Premium com quota antiga.
- Estratégia de divulgação e engajamento incluída.
- Materiais promocionais prontos incluídos.
- Landing page estática incluída.
- Termos e política de uso justo atualizados.
- Nove testes automatizados aprovados.
