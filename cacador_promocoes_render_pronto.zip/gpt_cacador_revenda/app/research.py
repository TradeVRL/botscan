from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any

from openai import OpenAI

from app.product_links import extract_product_links
from app.prompts import MODE_INSTRUCTIONS, SYSTEM_PROMPT
from app.settings import Settings
from app.utils import local_timestamp


@dataclass(slots=True)
class ResearchResult:
    text: str
    sources: list[dict[str, str]]
    product_links: list[dict[str, str]]
    response_id: str | None
    input_tokens: int
    output_tokens: int
    web_search_calls: int


def _extract_sources(response_data: dict[str, Any]) -> list[dict[str, str]]:
    sources: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(url: str | None, title: str | None = None) -> None:
        if not url or url in seen:
            return
        seen.add(url)
        sources.append({"url": url, "title": title or url})

    for item in response_data.get("output", []):
        if item.get("type") == "message":
            for content in item.get("content", []):
                for annotation in content.get("annotations", []):
                    if annotation.get("type") == "url_citation":
                        citation = annotation.get("url_citation", annotation)
                        add(citation.get("url"), citation.get("title"))
        if item.get("type") == "web_search_call":
            action = item.get("action") or {}
            for source in action.get("sources", []) or []:
                add(source.get("url"), source.get("title") or source.get("name"))
    return sources


def _append_sources(text: str, sources: list[dict[str, str]], max_sources: int = 12) -> str:
    if not sources:
        return text
    lines = ["", "🔗 FONTES CONSULTADAS"]
    for index, source in enumerate(sources[:max_sources], start=1):
        title = source.get("title", "Fonte").strip()
        url = source.get("url", "").strip()
        lines.append(f"{index}. {title}\n{url}")
    return text.rstrip() + "\n" + "\n".join(lines)


def _format_brl(value: float | int) -> str:
    formatted = f"{float(value):,.2f}"
    return "R$ " + formatted.replace(",", "X").replace(".", ",").replace("X", ".")


def run_research(
    *,
    settings: Settings,
    command: str,
    depth: str,
    query: str,
    image_bytes: bytes | None = None,
    destination_cep: str = "",
    destination_region: str = "",
) -> ResearchResult:
    client = OpenAI(api_key=settings.openai_api_key, timeout=settings.openai_timeout_seconds)
    mode_instruction = MODE_INSTRUCTIONS.get(command, MODE_INSTRUCTIONS["general"])
    detail_instruction = (
        "Faça análise profunda, amplie a validação cruzada e detalhe os três cenários."
        if depth == "deep"
        else "Faça análise expressa, priorizando até cinco oportunidades realmente úteis."
    )
    user_text = f"""
DATA E HORA LOCAL: {local_timestamp(settings.timezone)}
TIPO DE PESQUISA: {command}
ORIENTAÇÃO DO MODO: {mode_instruction}
PROFUNDIDADE: {detail_instruction}
DESTINO PARA FRETE: CEP {destination_cep or "não informado"}; localidade {destination_region or "a confirmar"}.
PARÂMETROS DE REVENDA, QUANDO APLICÁVEIS: capital {_format_brl(settings.default_capital_brl)}; margem mínima {settings.default_margin_percent}%; ROI mínimo {settings.default_roi_percent}%; máximo de {settings.default_max_product_allocation_percent}% por produto.
SOLICITAÇÃO DO CLIENTE: {query or 'Use os parâmetros padrão e realize a pesquisa.'}

Regras adicionais:
- Pesquise dados atuais na internet.
- Inclua links diretos dos produtos e deixe claro o que foi confirmado ou estimado.
- Não utilize o maior preço isolado para justificar margem.
- Se não houver informação suficiente para um cálculo responsável, reduza a classificação ou descarte.
- Produza texto adequado ao Telegram, sem tabela larga.
- Tente confirmar o frete para o CEP informado. Quando a loja exigir carrinho ou login, marque o frete como A CONFIRMAR ou use estimativa conservadora.
- O bloco PRODUCT_LINKS_JSON é obrigatório e será transformado em botões; não mencione esse bloco no relatório visível.
""".strip()

    input_payload: str | list[dict[str, Any]]
    if image_bytes:
        encoded = base64.b64encode(image_bytes).decode("ascii")
        input_payload = [
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": user_text},
                    {"type": "input_image", "image_url": f"data:image/jpeg;base64,{encoded}"},
                ],
            }
        ]
    else:
        input_payload = user_text

    context_size = "high" if depth == "deep" else "medium"
    reasoning_effort = "high" if depth == "deep" else "low"
    response = client.responses.create(
        model=settings.openai_model,
        instructions=SYSTEM_PROMPT,
        input=input_payload,
        tools=[{"type": "web_search", "search_context_size": context_size}],
        tool_choice="auto",
        include=["web_search_call.action.sources"],
        reasoning={"effort": reasoning_effort},
        max_output_tokens=settings.openai_max_output_tokens,
        store=False,
    )
    data = response.model_dump()
    sources = _extract_sources(data)
    raw_text = (response.output_text or "").strip()
    if not raw_text:
        raise RuntimeError("A pesquisa terminou sem conteúdo utilizável")
    text, product_links = extract_product_links(raw_text)
    text = _append_sources(text, sources)
    usage = data.get("usage") or {}
    web_search_calls = sum(1 for item in data.get("output", []) if item.get("type") == "web_search_call")
    return ResearchResult(
        text=text,
        sources=sources,
        product_links=product_links,
        response_id=getattr(response, "id", None),
        input_tokens=int(usage.get("input_tokens") or 0),
        output_tokens=int(usage.get("output_tokens") or 0),
        web_search_calls=web_search_calls,
    )


