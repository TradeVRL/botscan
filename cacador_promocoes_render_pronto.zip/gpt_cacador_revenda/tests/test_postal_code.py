from app.postal_code import format_cep, normalize_cep


def test_normalize_cep_accepts_formatted_value() -> None:
    assert normalize_cep("72400-000") == "72400000"


def test_normalize_cep_rejects_invalid_value() -> None:
    assert normalize_cep("7240") is None


def test_format_cep() -> None:
    assert format_cep("72400000") == "72400-000"
