from __future__ import annotations

import hmac

from redis import Redis

from app.settings import Settings


def valid_webhook_secret(received: str | None, settings: Settings) -> bool:
    if not received:
        return False
    return hmac.compare_digest(received, settings.telegram_webhook_secret)


def accept_update_once(redis: Redis, update_id: int) -> bool:
    return bool(redis.set(f"telegram:update:{update_id}", "1", nx=True, ex=86400))


def within_rate_limit(redis: Redis, telegram_id: int, settings: Settings) -> bool:
    key = f"rate:{telegram_id}"
    value = redis.incr(key)
    if value == 1:
        redis.expire(key, settings.rate_limit_window_seconds)
    return value <= settings.rate_limit_requests
