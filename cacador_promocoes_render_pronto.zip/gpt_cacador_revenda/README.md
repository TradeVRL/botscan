# GPT Caçador de Oportunidades de Revenda

Bot comercial para Telegram que pesquisa preços na internet, compara concorrentes e produz relatórios de viabilidade de revenda com custo total, margem líquida, ROI, risco e fontes consultadas.

## O que está incluído

- Bot Telegram com webhook seguro.
- Pesquisa atualizada pela OpenAI Responses API com ferramenta de busca na web.
- Entrada por texto, link e foto de produto.
- Modos expresso e profundo.
- Fila de processamento com Celery e Render Key Value.
- Banco PostgreSQL para usuários, planos, histórico e relatórios.
- Controle de acesso, teste, bloqueio, validade e franquia mensal.
- Comandos administrativos pelo Telegram.
- Proteção contra atualizações duplicadas, excesso de mensagens e chamadas simultâneas.
- Relatórios extensos enviados também como arquivo `.txt`.
- Health check para o Render.
- Docker Compose para desenvolvimento local.
- Testes e pipeline de CI.

## Arquitetura

1. O Telegram envia a mensagem ao serviço FastAPI por webhook.
2. O serviço valida o segredo, registra o usuário, verifica o plano e reserva um crédito.
3. A solicitação é colocada na fila do Celery.
4. O worker consulta a internet pela OpenAI, gera o relatório e salva o resultado.
5. O relatório é enviado ao usuário no Telegram com links das fontes.

Essa separação impede que pesquisas demoradas bloqueiem o recebimento de novas mensagens.

## Estrutura

```text
app/
  main.py             API FastAPI e webhook
  handlers.py         comandos, menu e controle de acesso
  tasks.py            processamento assíncrono das pesquisas
  research.py         integração OpenAI e extração de fontes
  prompts.py          regras do analista de revenda
  repositories.py     usuários, franquias e histórico
  telegram_api.py     integração direta com Telegram Bot API
  models.py           modelos PostgreSQL
  settings.py         variáveis de ambiente
render.yaml            infraestrutura no Render
Dockerfile             imagem opcional
Docker-compose.yml     ambiente local
```

## 1. Criar o bot no Telegram

1. Abra o `@BotFather` no Telegram.
2. Execute `/newbot`.
3. Defina nome e username.
4. Copie o token informado.
5. Use `/setdescription`, `/setabouttext` e `/setuserpic` para profissionalizar o perfil.

O menu de comandos é configurado automaticamente no primeiro deploy.

## 2. Criar a chave OpenAI

Crie uma chave de projeto na plataforma da OpenAI e configure limite de gastos compatível com os planos vendidos. O custo da pesquisa depende do modelo, quantidade de buscas, contexto e tamanho do relatório.

## 3. Descobrir seu ID de administrador

Você pode usar temporariamente um bot de identificação no Telegram ou iniciar este projeto localmente. Depois, envie `/id` ao bot. Configure o número em `ADMIN_USER_IDS`.

Para mais de um administrador:

```env
ADMIN_USER_IDS=123456789,987654321
```

## 4. Deploy no Render

1. Crie um repositório GitHub e envie todos os arquivos deste projeto.
2. No Render, selecione **New > Blueprint**.
3. Escolha o repositório.
4. O `render.yaml` criará:
   - serviço web FastAPI;
   - background worker Celery;
   - PostgreSQL;
   - Render Key Value para fila.
5. Preencha as variáveis secretas solicitadas para o serviço web e para o worker:
   - `TELEGRAM_BOT_TOKEN`;
   - `TELEGRAM_WEBHOOK_SECRET`;
   - `OPENAI_API_KEY`;
   - `ADMIN_USER_IDS`;
   - `SUPPORT_CONTACT`;
   - `SALES_MESSAGE`.

Use exatamente o mesmo token, chave OpenAI, administradores e segredo de webhook nos dois serviços.

Gere um segredo compatível com o Telegram:

```bash
python scripts/generate_webhook_secret.py
```

O segredo deve conter somente letras, números, `_` e `-`.

O código identifica automaticamente o domínio `onrender.com` e registra o webhook. Não é necessário preencher `PUBLIC_BASE_URL` no Render, salvo quando usar domínio próprio.

## 5. Primeiro acesso

1. Aguarde o web service e o worker ficarem ativos.
2. Abra o bot e envie `/start`.
3. Envie `/id` para conferir seu identificador.
4. Como administrador, ative um cliente que já tenha iniciado o bot:

```text
/admin_ativar 123456789 basico 30
```

Formato:

```text
/admin_ativar ID plano dias quota_opcional
```

Exemplos:

```text
/admin_ativar 123456789 basico 30
/admin_ativar 123456789 pro 90 100
/admin_ativar 123456789 empresarial 365 0
```

Quota `0` significa acesso ilimitado.

Outros comandos administrativos:

```text
/admin_bloquear ID
/admin_creditos ID quantidade
/admin_stats
```

## Comandos do usuário

```text
/start
/ajuda
/planos
/status
/historico
/id
/pesquisar descrição da pesquisa
```

Também são aceitos:

```text
VARREDURA GERAL
VARREDURA AMAZON
VARREDURA FORNECEDORES
VARREDURA PROMOÇÕES
ANALISAR PRODUTO
ANALISAR FORNECEDOR
COMPARAR MARKETPLACES
ATUALIZAR RELATÓRIO
MODO PROFUNDO ANALISAR PRODUTO <link>
```

Uma foto enviada ao bot é tratada como `ANALISAR PRODUTO`. Recomenda-se incluir na legenda preço, loja, modelo e condições observadas.

## Planos e franquias

Os valores padrão ficam no ambiente. No `render.yaml`, o teste gratuito inicia desativado para evitar abuso; habilite-o somente quando decidir oferecer demonstração:

```env
TRIAL_ENABLED=true
TRIAL_QUOTA=2
BASIC_MONTHLY_QUOTA=20
PRO_MONTHLY_QUOTA=60
ENTERPRISE_MONTHLY_QUOTA=0
```

Este projeto inclui ativação manual pelo administrador. Cobrança automática não foi conectada a uma adquirente específica. Para comercialização, você pode colocar instruções de contratação em `SALES_MESSAGE` e ativar o usuário após a confirmação do pagamento.

Antes de integrar pagamento automático, defina política de reembolso, emissão fiscal, suporte, renovação e tratamento de chargeback.

## Desenvolvimento local

1. Copie o arquivo de ambiente:

```bash
cp .env.example .env
```

2. Ajuste token do Telegram, OpenAI e administradores.
3. Suba os serviços:

```bash
docker compose up --build
```

Para receber webhook localmente, use um domínio HTTPS público de desenvolvimento e configure `PUBLIC_BASE_URL`.

## Execução sem Docker

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --port 10000
```

Em outro terminal:

```bash
celery -A app.celery_app:celery_app worker --loglevel=INFO --concurrency=2
```

## Testes

```bash
ruff check app tests
pytest -q
```

## Variáveis principais

| Variável | Finalidade |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Token criado no BotFather |
| `TELEGRAM_WEBHOOK_SECRET` | Validação das chamadas do Telegram |
| `OPENAI_API_KEY` | Chave da API OpenAI |
| `OPENAI_MODEL` | Modelo de pesquisa |
| `DATABASE_URL` | PostgreSQL |
| `REDIS_URL` | Fila Celery e controles rápidos |
| `ADMIN_USER_IDS` | Administradores separados por vírgula |
| `TRIAL_ENABLED` | Libera ou não acesso inicial |
| `TRIAL_QUOTA` | Pesquisas no teste |
| `MAX_ACTIVE_REQUESTS_PER_USER` | Evita pesquisas simultâneas do mesmo cliente |

## Operação recomendada

- Comece com poucos clientes e acompanhe custo médio por pesquisa.
- Defina o preço dos planos com margem sobre OpenAI, Render, impostos, suporte e inadimplência.
- Não anuncie lucro garantido nem “menor preço da internet”.
- Revise relatórios com reclamações dos usuários e ajuste o prompt somente após observar falhas repetidas.
- Mantenha `TRIAL_QUOTA` baixo para reduzir abuso.
- Não exponha `.env`, tokens ou credenciais em logs e repositórios.
- Faça backup e defina retenção compatível com sua política de privacidade.

## Limitações reais

- Alguns sites bloqueiam indexação, exigem login ou calculam frete apenas no carrinho.
- Estoque, cupom, preço e tarifa podem mudar depois da pesquisa.
- A busca pode não confirmar EAN, nota fiscal, restrição de marca ou condição tributária.
- A análise é apoio à decisão, não garantia de venda ou rentabilidade.
- O usuário deve confirmar a oferta e as regras do marketplace antes de comprar.

## Próximas evoluções comerciais

- Pagamento automático e renovação.
- Painel web de clientes, planos e consumo.
- Exportação em PDF e planilha.
- Alertas periódicos de queda de preço.
- Catálogo privado de oportunidades aprovadas.
- Métricas de custo por pesquisa e margem por plano.
- Termos de uso e política de privacidade revisados juridicamente.
