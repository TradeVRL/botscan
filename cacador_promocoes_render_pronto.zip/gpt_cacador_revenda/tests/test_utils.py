from app.utils import detect_research_command, split_text


def test_detect_deep_product_command() -> None:
    command, query, depth = detect_research_command(
        "MODO PROFUNDO ANALISAR PRODUTO https://exemplo.com/item"
    )
    assert command == "product"
    assert query == "https://exemplo.com/item"
    assert depth == "deep"


def test_detect_promotions_without_accent() -> None:
    command, query, depth = detect_research_command("VARREDURA PROMOCOES ferramentas")
    assert command == "promotions"
    assert query == "ferramentas"
    assert depth == "express"


def test_split_text_respects_limit() -> None:
    chunks = split_text("palavra " * 2000, limit=500)
    assert len(chunks) > 1
    assert all(len(chunk) <= 500 for chunk in chunks)
