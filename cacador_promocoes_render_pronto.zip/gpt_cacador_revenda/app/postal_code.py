from __future__ import annotations

import re
from dataclasses import dataclass

import httpx


@dataclass(slots=True)
class CepInfo:
    cep: str
    city: str = ""
    state: str = ""
    neighborhood: str = ""
    street: str = ""
    verified: bool = False


def normalize_cep(value: str) -> str | None:
    digits = re.sub(r"\D", "", value or "")
    if len(digits) != 8:
        return None
    return digits


def format_cep(value: str | None) -> str:
    digits = normalize_cep(value or "")
    if not digits:
        return "não informado"
    return f"{digits[:5]}-{digits[5:]}"


async def lookup_cep(value: str) -> CepInfo | None:
    cep = normalize_cep(value)
    if not cep:
        return None

    try:
        async with httpx.AsyncClient(timeout=8) as client:
            response = await client.get(f"https://viacep.com.br/ws/{cep}/json/")
            response.raise_for_status()
            payload = response.json()
        if payload.get("erro"):
            return None
        return CepInfo(
            cep=cep,
            city=str(payload.get("localidade") or "").strip(),
            state=str(payload.get("uf") or "").strip(),
            neighborhood=str(payload.get("bairro") or "").strip(),
            street=str(payload.get("logradouro") or "").strip(),
            verified=True,
        )
    except (httpx.HTTPError, ValueError, TypeError):
        # O CEP ainda pode ser armazenado e validado novamente na pesquisa.
        return CepInfo(cep=cep, verified=False)
