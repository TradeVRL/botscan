# Estratégia de divulgação e engajamento

## 1. Posicionamento

**Promessa principal:** antes de comprar, consulte o Caçador de Promoções.

O serviço não deve se posicionar apenas como mais um canal de ofertas. O diferencial é combinar:

- pesquisa personalizada;
- comparação do mesmo produto;
- verificação do desconto real;
- frete considerado pelo CEP;
- links diretos para compra;
- ferramentas de revenda no Premium.

Frase de posicionamento:

> Pesquise antes de comprar. O bot compara preços, considera o frete e mostra se a promoção vale a pena.

## 2. Modelo de aquisição

### Entrada gratuita

- 20 consultas por mês;
- cadastro simples pelo Telegram;
- CEP informado uma única vez;
- valor entregue antes da cobrança;
- nenhum cartão exigido para testar.

### Conversão para Premium

Preço: **R$ 9,90 por 30 dias**.

Gatilhos de conversão dentro do bot:

1. usuário toca em Revenda Premium;
2. usuário chega a cinco consultas restantes;
3. usuário utiliza as 20 consultas;
4. usuário solicita análise profunda;
5. usuário procura fornecedores ou comparação entre marketplaces.

A comunicação deve enfatizar utilidade, não pressão:

> Uma economia em uma única compra pode pagar vários meses do Premium.

## 3. Públicos prioritários

### Consumidores que pesquisam antes de comprar

Interesses: eletrodomésticos, ferramentas, eletrônicos, informática, casa, automotivo e material de construção.

### Caçadores de promoções

Participam de grupos de WhatsApp, Telegram, Facebook e comunidades de cupons.

### Pequenos revendedores

Vendem na Amazon, Mercado Livre, Shopee, Instagram ou WhatsApp e precisam comparar compra, taxas e margem.

### Profissionais autônomos

Eletricistas, mecânicos, marceneiros, instaladores, técnicos e profissionais que compram ferramentas ou insumos com frequência.

## 4. Canais de divulgação

### WhatsApp

Canal inicial mais eficiente. Utilizar:

- status pessoal;
- grupos de condomínio, família e trabalho, respeitando as regras;
- grupos de ofertas;
- listas de transmissão com autorização;
- mensagem individual para primeiros usuários.

### Instagram

Publicar:

- Reels curtos mostrando preço anunciado versus preço real;
- Stories com enquete “Essa promoção vale a pena?”;
- cards de ofertas analisadas;
- demonstração da pesquisa dentro do Telegram;
- depoimentos reais, com autorização.

### Telegram

Criar um canal público complementar:

- publicar de uma a três ofertas realmente boas por dia;
- usar o bot como chamada principal;
- não saturar com dezenas de promoções fracas;
- fixar a mensagem de acesso gratuito.

### Facebook e comunidades locais

Publicar em grupos de:

- promoções;
- compra e venda;
- ferramentas;
- construção e reforma;
- automóveis;
- empreendedores e vendedores online.

### Parcerias

Buscar microinfluenciadores e administradores de grupos. Modelo sugerido:

- acesso Premium gratuito por período definido;
- comissão por cliente pagante, somente quando houver rastreamento confiável;
- cupom ou link identificador por parceiro em uma fase posterior.

## 5. Plano de lançamento em 30 dias

### Semana 1: validação fechada

- convidar 30 a 50 pessoas conhecidas;
- observar onde abandonam o fluxo;
- corrigir mensagens confusas;
- coletar cinco depoimentos;
- medir custo médio por consulta.

### Semana 2: lançamento orgânico

- publicar a mensagem principal em WhatsApp e Instagram;
- divulgar três demonstrações reais;
- abrir canal público no Telegram;
- convidar usuários a compartilhar pelo botão do bot.

### Semana 3: conteúdo recorrente

- publicar um comparativo por dia;
- fazer dois Reels mostrando o bot em uso;
- divulgar “oferta que parecia boa, mas não era”;
- apresentar a área Premium para revendedores.

### Semana 4: conversão

- lembrar usuários com poucas consultas;
- divulgar casos de economia real;
- destacar Premium a R$ 9,90;
- testar anúncio pago pequeno, somente após medir retenção e custo operacional.

## 6. Rotina de conteúdo

### Segunda-feira

“Top promoções para começar a semana”.

### Terça-feira

Comparação de preços de um produto popular.

### Quarta-feira

Conteúdo educativo: cupom, cashback, frete ou falso desconto.

### Quinta-feira

Demonstração de busca por foto ou link.

### Sexta-feira

Ofertas de maior intenção de compra.

### Sábado

Casa, ferramentas, automotivo e lazer.

### Domingo

Resumo das melhores análises e chamada para a semana seguinte.

## 7. Engajamento dentro do bot

- menu em todos os momentos importantes;
- resultado com botões diretos das lojas;
- botão de nova pesquisa após cada relatório;
- contador de consultas visível sem dominar a experiência;
- convite para compartilhar o bot;
- mensagens de upgrade somente em momentos relevantes;
- histórico de consultas;
- alerta de que preço e estoque podem mudar;
- linguagem simples e objetiva.

## 8. Indicadores principais

Acompanhar semanalmente:

- novos usuários;
- usuários que informaram CEP;
- primeira consulta concluída;
- consultas por usuário;
- taxa de retorno em 7 e 30 dias;
- cliques nos links dos produtos, quando houver rastreamento;
- conversão Gratuito para Premium;
- cancelamento do Premium;
- custo médio de IA por usuário;
- receita por usuário;
- falhas de pesquisa e entrega.

Metas iniciais razoáveis para validação, não garantias:

- 60% dos novos usuários concluindo a primeira consulta;
- 25% retornando em até sete dias;
- 3% a 8% de conversão para Premium após o produto estar validado;
- falhas técnicas abaixo de 3%.

## 9. Proteção da margem do serviço

O plano Premium é ilimitado para uso individual, mas os termos devem proibir:

- automação externa;
- compartilhamento de conta;
- revenda de acesso;
- consultas em massa por robôs;
- uso que comprometa a estabilidade.

Manter:

- uma pesquisa ativa por usuário;
- rate limit;
- registro de consumo e buscas web;
- bloqueio administrativo;
- monitoramento do custo por plano.

O preço de R$ 9,90 é excelente para aquisição, mas só deve ser mantido se o custo médio mensal por assinante permitir margem. Revise o preço após os primeiros 100 pagantes.

## 10. Estratégia recomendada de preço

- Gratuito: 20 consultas mensais;
- Premium: R$ 9,90 por 30 dias;
- sem fidelidade;
- não oferecer descontos adicionais no lançamento;
- considerar plano anual apenas depois de validar retenção;
- manter o valor simples e fácil de comunicar.

## 11. Jornada comercial ideal

1. usuário vê demonstração;
2. toca no link do Telegram;
3. informa CEP;
4. faz a primeira consulta;
5. abre um produto diretamente pelo resultado;
6. volta para novas consultas;
7. encontra uma necessidade avançada ou consome a franquia;
8. ativa o Premium por R$ 9,90;
9. utiliza ferramentas de revenda ou consultas ilimitadas;
10. compartilha o bot.
