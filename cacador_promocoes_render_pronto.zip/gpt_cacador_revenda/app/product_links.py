from __future__ import annotations

import json
import re
from urllib.parse import urlparse

PRODUCT_LINKS_PATTERN = re.compile(
    r"\[\[PRODUCT_LINKS_JSON\]\]\s*(.*?)\s*\[\[END_PRODUCT_LINKS_JSON\]\]",
    re.DOTALL | re.IGNORECASE,
)


def _valid_https_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme == "https" and bool(parsed.netloc)
    except ValueError:
        return False


def extract_product_links(text: str, max_links: int = 8) -> tuple[str, list[dict[str, str]]]:
    """Remove o bloco técnico e devolve links válidos para botões do Telegram."""
    match = PRODUCT_LINKS_PATTERN.search(text)
    if not match:
        return text.strip(), []

    cleaned = PRODUCT_LINKS_PATTERN.sub("", text).strip()
    raw = match.group(1).strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE | re.DOTALL)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return cleaned, []

    if not isinstance(payload, list):
        return cleaned, []

    links: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in payload:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "Acessar oferta").strip()
        url = str(item.get("url") or "").strip()
        if not _valid_https_url(url) or url in seen:
            continue
        seen.add(url)
        links.append({"title": title[:45] or "Acessar oferta", "url": url})
        if len(links) >= max_links:
            break
    return cleaned, links


def result_metadata_to_json(
    sources: list[dict[str, str]], product_links: list[dict[str, str]]
) -> str:
    return json.dumps(
        {"sources": sources, "product_links": product_links},
        ensure_ascii=False,
    )


def product_links_from_metadata(value: str | None) -> list[dict[str, str]]:
    if not value:
        return []
    try:
        payload = json.loads(value)
    except json.JSONDecodeError:
        return []
    if isinstance(payload, dict):
        links = payload.get("product_links")
        return links if isinstance(links, list) else []
    return []
