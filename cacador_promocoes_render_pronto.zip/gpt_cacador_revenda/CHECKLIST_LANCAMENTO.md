# Checklist de lançamento

## Configuração técnica

- [ ] Criar bot no BotFather.
- [ ] Definir nome, username, descrição, foto e mensagem “Sobre”.
- [ ] Preencher `TELEGRAM_BOT_TOKEN`.
- [ ] Gerar `TELEGRAM_WEBHOOK_SECRET`.
- [ ] Informar `TELEGRAM_BOT_USERNAME`.
- [ ] Configurar OpenAI, PostgreSQL e Redis.
- [ ] Configurar administradores.
- [ ] Inserir contato de suporte.
- [ ] Criar checkout de R$ 9,90 e informar `LICENSE_PAYMENT_URL`.
- [ ] Fazer deploy do web service e worker no Render.
- [ ] Testar `/start`, CEP, menus, foto, link e texto.
- [ ] Confirmar botões de acesso aos produtos.
- [ ] Testar limite das 20 consultas.
- [ ] Testar Premium ilimitado.
- [ ] Testar expiração e reativação da licença.

## Operação comercial

- [ ] Definir empresa responsável e emissão fiscal.
- [ ] Publicar termos de uso e privacidade.
- [ ] Definir cancelamento, reembolso e suporte.
- [ ] Monitorar custo médio por consulta.
- [ ] Monitorar uso anormal do Premium.
- [ ] Definir horário e SLA de atendimento.

## Divulgação

- [ ] Substituir `@SEU_BOT` nos materiais.
- [ ] Personalizar a landing page.
- [ ] Criar canal público de ofertas.
- [ ] Preparar três demonstrações reais.
- [ ] Convidar primeiros 30 a 50 testadores.
- [ ] Coletar depoimentos autorizados.
- [ ] Publicar WhatsApp, Instagram e Telegram.
- [ ] Medir cadastro, primeira consulta, retorno e conversão.
