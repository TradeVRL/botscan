from app.product_links import extract_product_links, product_links_from_metadata, result_metadata_to_json


def test_extract_product_links_removes_technical_block() -> None:
    text = """Oferta aprovada.\n[[PRODUCT_LINKS_JSON]]\n[{\"title\":\"Produto - Loja\",\"url\":\"https://loja.exemplo/produto\"}]\n[[END_PRODUCT_LINKS_JSON]]"""
    cleaned, links = extract_product_links(text)
    assert cleaned == "Oferta aprovada."
    assert links == [{"title": "Produto - Loja", "url": "https://loja.exemplo/produto"}]


def test_extract_product_links_rejects_non_https_and_duplicates() -> None:
    text = """Resultado.\n[[PRODUCT_LINKS_JSON]]\n[
      {\"title\":\"Inseguro\",\"url\":\"http://loja.exemplo/produto\"},
      {\"title\":\"Seguro\",\"url\":\"https://loja.exemplo/produto\"},
      {\"title\":\"Repetido\",\"url\":\"https://loja.exemplo/produto\"}
    ]\n[[END_PRODUCT_LINKS_JSON]]"""
    _, links = extract_product_links(text)
    assert links == [{"title": "Seguro", "url": "https://loja.exemplo/produto"}]


def test_product_links_metadata_roundtrip() -> None:
    links = [{"title": "Oferta", "url": "https://loja.exemplo/item"}]
    payload = result_metadata_to_json([], links)
    assert product_links_from_metadata(payload) == links
