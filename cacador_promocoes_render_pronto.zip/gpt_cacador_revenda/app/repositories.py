from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import ResearchRequest, User
from app.postal_code import CepInfo
from app.settings import Settings


BASIC_COMMANDS = {"promotions", "product"}
LICENSED_PLANS = {"pro", "premium", "empresarial", "admin"}


def _period_now() -> str:
    return datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%Y-%m")


def _downgrade_expired_license(user: User, settings: Settings) -> None:
    now = datetime.now(timezone.utc)
    if (
        user.plan in LICENSED_PLANS - {"admin"}
        and user.subscription_expires_at
        and user.subscription_expires_at < now
    ):
        user.plan = "basico"
        user.status = "active"
        user.subscription_expires_at = None
        user.monthly_quota = settings.basic_monthly_quota
        user.quota_used = 0
        user.quota_period = _period_now()


def upsert_user(session: Session, telegram_user: dict, settings: Settings) -> User:
    telegram_id = int(telegram_user["id"])
    user = session.scalar(select(User).where(User.telegram_id == telegram_id))
    full_name = " ".join(
        part for part in [telegram_user.get("first_name", ""), telegram_user.get("last_name", "")] if part
    ).strip()
    now = datetime.now(timezone.utc)

    if user is None:
        is_admin = telegram_id in settings.admin_ids
        user = User(
            telegram_id=telegram_id,
            username=telegram_user.get("username"),
            full_name=full_name,
            status="active",
            plan="admin" if is_admin else "basico",
            monthly_quota=0 if is_admin else settings.basic_monthly_quota,
            quota_period=_period_now(),
            last_seen_at=now,
        )
        session.add(user)
        session.flush()
        return user

    user.username = telegram_user.get("username")
    user.full_name = full_name
    user.last_seen_at = now

    if telegram_id in settings.admin_ids:
        user.status = "active"
        user.plan = "admin"
        user.monthly_quota = 0
        user.subscription_expires_at = None
    elif user.status != "blocked":
        # Compatibilidade com cadastros das versões anteriores.
        if user.plan == "trial" or user.status == "pending":
            user.status = "active"
            user.plan = "basico"
            user.monthly_quota = settings.basic_monthly_quota
            user.quota_used = 0
            user.quota_period = _period_now()
        _downgrade_expired_license(user, settings)
        # Atualiza cadastros básicos criados com franquias antigas, sem remover créditos extras.
        if user.plan == "basico" and user.monthly_quota < settings.basic_monthly_quota:
            user.monthly_quota = settings.basic_monthly_quota
        if user.plan in {"pro", "premium"} and settings.pro_monthly_quota == 0:
            user.monthly_quota = 0

    session.flush()
    return user


def get_user_by_telegram_id(session: Session, telegram_id: int) -> User | None:
    return session.scalar(select(User).where(User.telegram_id == telegram_id))


def get_user_by_id(session: Session, user_id: int) -> User | None:
    return session.get(User, user_id)


def save_postal_code(session: Session, user_id: int, info: CepInfo) -> User | None:
    user = session.get(User, user_id)
    if not user:
        return None
    user.postal_code = info.cep
    user.postal_city = info.city or None
    user.postal_state = info.state or None
    session.flush()
    return user


def refresh_quota_period(user: User) -> None:
    period = _period_now()
    if user.quota_period != period:
        user.quota_period = period
        user.quota_used = 0


def is_licensed(user: User, settings: Settings) -> bool:
    _downgrade_expired_license(user, settings)
    return user.status == "active" and user.plan in LICENSED_PLANS


def validate_feature_access(
    user: User,
    command: str,
    depth: str,
    settings: Settings,
) -> tuple[bool, str]:
    if command in BASIC_COMMANDS and depth != "deep":
        return True, ""
    if is_licensed(user, settings):
        return True, ""
    return False, "Esta função faz parte da licença Premium."


def validate_access(user: User, settings: Settings) -> tuple[bool, str]:
    refresh_quota_period(user)
    _downgrade_expired_license(user, settings)
    if user.status == "blocked":
        return False, "Seu acesso está bloqueado. Fale com o suporte."
    if user.status != "active":
        return False, "Seu acesso ainda não está ativo."
    if user.monthly_quota > 0 and user.quota_used >= user.monthly_quota:
        return False, "Sua franquia mensal foi utilizada. Você pode aguardar a renovação ou ativar a licença Premium."
    return True, ""


def reserve_quota(
    session: Session,
    user_id: int,
    settings: Settings,
    command: str,
    depth: str,
    max_active_requests: int | None = None,
) -> tuple[bool, str, User]:
    user = session.scalar(select(User).where(User.id == user_id).with_for_update())
    if user is None:
        raise LookupError("Usuário não encontrado")
    allowed, reason = validate_access(user, settings)
    if not allowed:
        return False, reason, user
    allowed, reason = validate_feature_access(user, command, depth, settings)
    if not allowed:
        return False, reason, user
    if not user.postal_code:
        return False, "Cadastre seu CEP antes de pesquisar para que o frete seja considerado.", user
    if max_active_requests is not None and active_request_count(session, user.id) >= max_active_requests:
        return False, "Você já possui uma pesquisa em processamento. Aguarde a conclusão.", user
    user.quota_used += 1
    session.flush()
    return True, "", user


def refund_quota(session: Session, user_id: int) -> None:
    user = session.scalar(select(User).where(User.id == user_id).with_for_update())
    if user and user.quota_used > 0:
        user.quota_used -= 1
        session.flush()


def remaining_quota(user: User) -> str:
    refresh_quota_period(user)
    if user.monthly_quota == 0:
        return "ilimitada"
    return str(max(user.monthly_quota - user.quota_used, 0))


def active_request_count(session: Session, user_id: int) -> int:
    return int(
        session.scalar(
            select(func.count(ResearchRequest.id)).where(
                ResearchRequest.user_id == user_id,
                ResearchRequest.status.in_(["queued", "processing", "delivering"]),
            )
        )
        or 0
    )


def create_research_request(
    session: Session,
    *,
    user_id: int,
    chat_id: int,
    message_id: int | None,
    command: str,
    mode: str,
    query: str,
    input_type: str = "text",
    telegram_file_id: str | None = None,
) -> ResearchRequest:
    request = ResearchRequest(
        user_id=user_id,
        telegram_chat_id=chat_id,
        telegram_message_id=message_id,
        command=command,
        mode=mode,
        query=query,
        input_type=input_type,
        telegram_file_id=telegram_file_id,
        status="queued",
    )
    session.add(request)
    session.flush()
    return request


def get_request(session: Session, request_id: str) -> ResearchRequest | None:
    return session.get(ResearchRequest, request_id)


def recent_requests(session: Session, user_id: int, limit: int = 5) -> list[ResearchRequest]:
    return list(
        session.scalars(
            select(ResearchRequest)
            .where(ResearchRequest.user_id == user_id)
            .order_by(ResearchRequest.created_at.desc())
            .limit(limit)
        )
    )


def activate_user(
    session: Session,
    telegram_id: int,
    plan: str,
    days: int,
    quota: int | None,
    settings: Settings,
) -> User | None:
    user = get_user_by_telegram_id(session, telegram_id)
    if not user:
        return None
    normalized_plan = "pro" if plan == "premium" else plan
    user.status = "active"
    user.plan = normalized_plan
    user.monthly_quota = settings.quota_for_plan(normalized_plan) if quota is None else max(quota, 0)
    user.quota_used = 0
    user.quota_period = _period_now()
    user.subscription_expires_at = (
        datetime.now(timezone.utc) + timedelta(days=days)
        if days > 0 and normalized_plan not in {"basico", "admin"}
        else None
    )
    session.flush()
    return user


def block_user(session: Session, telegram_id: int) -> User | None:
    user = get_user_by_telegram_id(session, telegram_id)
    if user:
        user.status = "blocked"
        session.flush()
    return user


def add_credits(session: Session, telegram_id: int, credits: int) -> User | None:
    user = get_user_by_telegram_id(session, telegram_id)
    if user:
        refresh_quota_period(user)
        if user.monthly_quota > 0:
            user.monthly_quota = max(user.monthly_quota + credits, 0)
        session.flush()
    return user


def service_stats(session: Session) -> dict[str, int]:
    users = int(session.scalar(select(func.count(User.id))) or 0)
    active_users = int(session.scalar(select(func.count(User.id)).where(User.status == "active")) or 0)
    premium_users = int(
        session.scalar(select(func.count(User.id)).where(User.plan.in_(["pro", "premium", "empresarial"])))
        or 0
    )
    total_requests = int(session.scalar(select(func.count(ResearchRequest.id))) or 0)
    completed = int(
        session.scalar(select(func.count(ResearchRequest.id)).where(ResearchRequest.status == "completed"))
        or 0
    )
    failed = int(
        session.scalar(select(func.count(ResearchRequest.id)).where(ResearchRequest.status == "failed"))
        or 0
    )
    input_tokens = int(session.scalar(select(func.coalesce(func.sum(ResearchRequest.input_tokens), 0))) or 0)
    output_tokens = int(session.scalar(select(func.coalesce(func.sum(ResearchRequest.output_tokens), 0))) or 0)
    web_search_calls = int(
        session.scalar(select(func.coalesce(func.sum(ResearchRequest.web_search_calls), 0))) or 0
    )
    return {
        "users": users,
        "active_users": active_users,
        "premium_users": premium_users,
        "total_requests": total_requests,
        "completed": completed,
        "failed": failed,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "web_search_calls": web_search_calls,
    }
