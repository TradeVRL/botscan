# Simulação da experiência no Telegram

## 1. Primeiro acesso

**Usuário**

`/start`

**Bot**

🔥 **Bem-vindo ao Caçador de Promoções**

Eu comparo preços na internet, verifico se o desconto é real e considero o frete para o seu endereço.

📍 Para começar, envie seu CEP.

Exemplo: `72400-000`

**Usuário**

`72400-000`

**Bot**

✅ **CEP confirmado: 72400-000 • Brasília/DF**

O frete será pesquisado ou estimado para esse destino.

Você ganhou **20 consultas gratuitas por mês**.

**Menu por botões**

| Botão | Botão |
|---|---|
| 🔥 Promoções agora | 🔎 Buscar produto |
| 🏷️ Cupons | 📂 Categorias |
| 🕘 Histórico | 👤 Minha conta |
| 🔒 Revenda Premium | ⭐ Premium R$ 9,90 |
| ❓ Ajuda | 📤 Compartilhar |

---

## 2. Pesquisa de promoções

**Usuário toca em:** `🔥 Promoções agora`

**Bot**

🔥 **Escolha uma categoria**

| Botão | Botão |
|---|---|
| 🌐 Todas | 📱 Eletrônicos |
| 🏠 Casa e cozinha | 🛠️ Ferramentas |
| 🚗 Automotivo | 💻 Informática |
| 🧴 Beleza | ✍️ Digitar produto |
| 🏠 Menu principal | |

**Usuário toca em:** `🛠️ Ferramentas`

**Bot**

✅ **Pesquisa recebida**

Protocolo: `A81F2C90`

Consultas gratuitas restantes: **19**

**Bot, durante a pesquisa**

🔍 **Pesquisando promoções reais**

📍 CEP de destino: 72400-000

Estou comparando preços, frete, cupons, histórico e confiabilidade das lojas.

---

## 3. Resultado com links diretos

**Bot**

🔥 **OFERTA EM DESTAQUE**

📦 Furadeira Bosch GSB 450 RE 220V  
🏪 Loja: Loja Exemplo  
💵 Preço atual: **R$ 239,90**  
🏷️ Cupom: **FERRAMENTA20**  
💳 Preço com cupom: **R$ 219,90**  
🚚 Frete para 72400-000: **R$ 18,90**  
💰 Custo final: **R$ 238,80**

📊 Mediana pesquisada: **R$ 319,90**  
📉 Economia estimada: **R$ 81,10**  
📉 Desconto real: **25,4%**

🛡️ Confiabilidade da loja: alta  
⭐ Avaliação: **Excelente oferta**

⚠️ Confirme estoque, cupom e prazo no pagamento.

✅ **Decisão: APROVEITAR**

**Botões abaixo do resultado**

`🛒 Furadeira Bosch • Loja Exemplo`

`🛒 Furadeira Bosch • Amazon`

`🛒 Furadeira Bosch • Magalu`

`🔥 Nova pesquisa`  `🏠 Menu`

`⭐ Premium ilimitado • R$ 9,90`

`📤 Compartilhar o bot`

Ao tocar no botão do produto, o usuário abre diretamente a oferta na loja.

---

## 4. Busca por produto

**Usuário toca em:** `🔎 Buscar produto`

**Bot**

🔎 **Qual produto você procura?**

Envie o nome, um link ou uma foto.

Exemplo: `Air fryer Mondial 5 litros 220V`

**Usuário**

`Depurador Suggar Slim 60 cm inox 220V DE62IX`

**Bot**

✅ Pesquisa recebida  
Protocolo: `B34A908F`  
Consultas gratuitas restantes: **18**

**Resultado**

✅ **MELHOR OFERTA VÁLIDA ENCONTRADA**

📦 Depurador Suggar DE62IX 220V  
🏪 Loja: Loja Exemplo  
💵 Produto: **R$ 379,90**  
🚚 Frete estimado para seu CEP: **R$ 29,90**  
💰 Custo final: **R$ 409,80**  
📊 Mediana pesquisada: **R$ 469,90**

⭐ Avaliação: **Boa oferta**

**Botões**

`🛒 Abrir oferta • Loja Exemplo`

`🛒 Comparar na Amazon`

`🔥 Nova pesquisa`  `🏠 Menu`

---

## 5. Minha conta no plano gratuito

**Usuário toca em:** `👤 Minha conta`

**Bot**

👤 **MINHA CONTA**

🆓 Plano: Gratuito  
📍 CEP: 72400-000 • Brasília/DF  
🔎 Consultas mensais: 20  
✅ Utilizadas: 2  
🎟️ Disponíveis: 18

**Botões**

`📍 Alterar CEP`  `⭐ Ver Premium`

`🕘 Histórico`  `📤 Compartilhar`

`💬 Suporte`  `🏠 Menu`

---

## 6. Tentativa de usar revenda

**Usuário toca em:** `🔒 Revenda Premium`

**Bot**

🔒 **REVENDA AVANÇADA**

Essa área foi criada para quem compra produtos para revender.

Inclui:

💰 Lucro líquido, margem e ROI  
🏪 Fornecedores e atacadistas  
📦 Revenda na Amazon  
📊 Comparação entre marketplaces  
⚖️ Ponto de equilíbrio  
📉 Cenários de risco

💎 **Premium ilimitado por apenas R$ 9,90 a cada 30 dias**

Sem fidelidade.

**Botões**

`💳 Ativar Premium`

`🏠 Continuar no Gratuito`

---

## 7. Tela de planos

**Usuário toca em:** `⭐ Premium R$ 9,90`

**Bot**

⭐ **PLANOS DO CAÇADOR DE PROMOÇÕES**

🆓 **GRATUITO**

• 20 consultas por mês  
• Promoções e cupons  
• Busca por nome, link ou foto  
• Comparação de preços  
• Frete pelo CEP  
• Links diretos para os produtos

💎 **PREMIUM ILIMITADO**

• Consultas ilimitadas para uso individual  
• Tudo do Gratuito  
• Revenda na Amazon, Mercado Livre e Shopee  
• Fornecedores e atacadistas  
• Margem, ROI e ponto de equilíbrio  
• Cenários de risco  
• Análises profundas  
• Histórico ampliado

💳 **R$ 9,90 por 30 dias**

**Botões**

`💳 Ativar Premium por R$ 9,90`

`🏠 Menu principal`

---

## 8. Usuário Premium

Após a ativação, o usuário recebe:

⭐ **Seu Premium foi ativado**

💎 Plano: Premium ilimitado  
📍 CEP: 72400-000 • Brasília/DF  
🔎 Consultas: ilimitadas  
📅 Validade: 30 dias

**Novo menu**

| Botão | Botão |
|---|---|
| 🔥 Promoções agora | 🔎 Buscar produto |
| 🏷️ Cupons | 📂 Categorias |
| 🕘 Histórico | 👤 Minha conta |
| 🧰 Revenda avançada | ⭐ Meu Premium |
| ❓ Ajuda | 📤 Compartilhar |

---

## 9. Revenda avançada liberada

**Usuário toca em:** `🧰 Revenda avançada`

**Bot**

🧰 **FERRAMENTAS PARA REVENDEDORES**

| Botão | Botão |
|---|---|
| 💰 Oportunidades | 📦 Revenda Amazon |
| 🏪 Fornecedores | 📊 Marketplaces |
| 🔍 Análise profunda | 🔄 Atualizar análise |
| 🏠 Menu principal | |

**Usuário toca em:** `📦 Revenda Amazon`

**Bot**

📦 **O que deseja pesquisar para revender na Amazon?**

Envie produto, categoria, marca, capital ou restrições.

**Usuário**

`Ferramentas Bosch. Capital R$ 3.000.`

**Resultado resumido**

💰 **OPORTUNIDADE PARA REVENDA**

📦 Kit Bosch 103 peças  
🏪 Fornecedor: Distribuidor Exemplo  
💵 Compra: R$ 279,90  
🚚 Frete rateado: R$ 12,00  
📦 Custo total: R$ 301,70

🛒 Venda sugerida: R$ 449,90  
💰 Lucro líquido: R$ 91,30  
📊 Margem líquida: 20,3%  
📈 ROI: 30,3%  
⚖️ Ponto de equilíbrio: R$ 335,60

✅ Decisão: **TESTAR 4 UNIDADES**

**Botões**

`🛒 Abrir fornecedor`

`🛒 Ver anúncio na Amazon`

`📊 Nova análise`  `🏠 Menu`

---

## 10. Últimas consultas gratuitas

Quando restarem cinco consultas, o bot acrescenta:

⚠️ Você ainda possui **5 consultas gratuitas** neste mês.

⭐ No Premium de R$ 9,90, as consultas são ilimitadas e a área de revenda é liberada.

**Botão:** `⭐ Conhecer o Premium`

---

## 11. Limite gratuito atingido

**Bot**

⚠️ **Suas 20 consultas gratuitas deste mês foram utilizadas**

Você pode aguardar a renovação mensal ou continuar agora com o Premium.

💎 Consultas ilimitadas  
🧰 Ferramentas de revenda  
💳 Apenas R$ 9,90 por 30 dias

**Botões**

`💳 Ativar Premium`

`🕘 Ver histórico`

`💬 Falar com suporte`

---

## 12. Compartilhamento

**Usuário toca em:** `📤 Compartilhar`

**Bot**

📤 **Compartilhe o Caçador de Promoções**

**Botão:** `📤 Enviar para um contato`

Mensagem sugerida pelo Telegram:

> Encontrei um bot que pesquisa promoções reais, compara preços e calcula o frete pelo CEP. Você pode fazer 20 consultas gratuitas por mês.
