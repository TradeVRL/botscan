from __future__ import annotations

import json
import logging
from datetime import timezone
from typing import Any

from redis import Redis

from app.celery_app import celery_app
from app.db import session_scope
from app.postal_code import format_cep, lookup_cep, normalize_cep
from app.repositories import (
    activate_user,
    active_request_count,
    add_credits,
    block_user,
    create_research_request,
    is_licensed,
    recent_requests,
    remaining_quota,
    reserve_quota,
    save_postal_code,
    service_stats,
    upsert_user,
    validate_access,
    validate_feature_access,
)
from app.security import within_rate_limit
from app.settings import Settings
from app.telegram_api import answer_callback_query, send_message_async
from app.utils import MODE_LABELS, detect_research_command

logger = logging.getLogger(__name__)


PROMOTION_CATEGORIES = {
    "all": "todas as categorias, priorizando ofertas com desconto real e boa confiabilidade",
    "electronics": "eletrônicos",
    "home": "casa, cozinha e utilidades domésticas",
    "tools": "ferramentas",
    "automotive": "automotivo",
    "computing": "informática",
    "beauty": "beleza e cuidados pessoais, excluindo medicamentos e suplementos",
}

COUPON_CATEGORIES = {
    "today": "cupons ativos hoje em lojas confiáveis",
    "amazon": "cupons e descontos válidos na Amazon Brasil",
    "marketplaces": "cupons em Mercado Livre e Shopee",
    "pix": "ofertas com desconto no Pix",
    "shipping": "ofertas com frete grátis ou frete reduzido",
}

PROMPTS_BY_MODE = {
    "general": "Informe a categoria, o capital e o marketplace desejado para a pesquisa avançada.",
    "amazon": "Informe o produto, categoria, capital ou restrições para revenda na Amazon Brasil.",
    "suppliers": "Informe a categoria, marca ou fornecedor que deseja pesquisar.",
    "promotions": "Informe a categoria ou o produto que deseja pesquisar.",
    "product": "Envie o nome, link ou foto do produto. Inclua preço e loja quando disponíveis.",
    "supplier_review": "Informe o nome, CNPJ ou link do fornecedor.",
    "marketplaces": "Informe o produto exato e, se souber, o custo de aquisição.",
    "update": "Informe o produto ou cole os dados da pesquisa que devem ser atualizados.",
}


def _format_brl(value: float) -> str:
    formatted = f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {formatted}"


def _is_admin(telegram_id: int, settings: Settings) -> bool:
    return telegram_id in settings.admin_ids


def _plan_label(plan: str) -> str:
    return {
        "basico": "Básico gratuito",
        "pro": "Premium",
        "premium": "Premium",
        "empresarial": "Empresarial",
        "admin": "Administrador",
    }.get(plan, plan.title())


def _status_text(user: Any) -> str:
    expiry = "não se aplica"
    if user.subscription_expires_at:
        expiry = user.subscription_expires_at.astimezone(timezone.utc).strftime("%d/%m/%Y")
    location = format_cep(user.postal_code)
    if user.postal_city and user.postal_state:
        location += f" • {user.postal_city}/{user.postal_state}"
    return (
        f"👤 Plano: {_plan_label(user.plan)}\n"
        f"📍 CEP: {location}\n"
        f"🔎 Consultas mensais: {'ilimitadas' if user.monthly_quota == 0 else user.monthly_quota}\n"
        f"✅ Utilizadas: {user.quota_used}\n"
        f"🎟️ Disponíveis: {remaining_quota(user)}\n"
        f"📅 Licença válida até: {expiry}"
    )


def _main_menu(user: Any, settings: Settings) -> dict[str, Any]:
    advanced = "🧰 Revenda avançada" if is_licensed(user, settings) else "🔒 Revenda Premium"
    rows: list[list[dict[str, str]]] = [
        [
            {"text": "🔥 Promoções agora", "callback_data": "menu:promotions"},
            {"text": "🔎 Buscar produto", "callback_data": "menu:search"},
        ],
        [
            {"text": "🏷️ Cupons", "callback_data": "menu:coupons"},
            {"text": "📂 Categorias", "callback_data": "menu:categories"},
        ],
        [
            {"text": "🕘 Histórico", "callback_data": "menu:history"},
            {"text": "👤 Minha conta", "callback_data": "menu:account"},
        ],
        [
            {"text": advanced, "callback_data": "menu:advanced"},
            {"text": "⭐ Premium R$ 9,90", "callback_data": "menu:plans"},
        ],
        [
            {"text": "❓ Ajuda", "callback_data": "menu:help"},
            {"text": "📤 Compartilhar", "callback_data": "menu:share"},
        ],
    ]
    return {"inline_keyboard": rows}


PROMOTIONS_MENU = {
    "inline_keyboard": [
        [
            {"text": "🌐 Todas", "callback_data": "promo:all"},
            {"text": "📱 Eletrônicos", "callback_data": "promo:electronics"},
        ],
        [
            {"text": "🏠 Casa e cozinha", "callback_data": "promo:home"},
            {"text": "🛠️ Ferramentas", "callback_data": "promo:tools"},
        ],
        [
            {"text": "🚗 Automotivo", "callback_data": "promo:automotive"},
            {"text": "💻 Informática", "callback_data": "promo:computing"},
        ],
        [
            {"text": "🧴 Beleza", "callback_data": "promo:beauty"},
            {"text": "✍️ Digitar produto", "callback_data": "menu:search"},
        ],
        [{"text": "🏠 Menu principal", "callback_data": "menu:main"}],
    ]
}

COUPONS_MENU = {
    "inline_keyboard": [
        [
            {"text": "🔥 Cupons de hoje", "callback_data": "coupon:today"},
            {"text": "📦 Amazon", "callback_data": "coupon:amazon"},
        ],
        [
            {"text": "🛍️ Marketplaces", "callback_data": "coupon:marketplaces"},
            {"text": "💳 Desconto no Pix", "callback_data": "coupon:pix"},
        ],
        [{"text": "🚚 Frete grátis", "callback_data": "coupon:shipping"}],
        [{"text": "🏠 Menu principal", "callback_data": "menu:main"}],
    ]
}

ADVANCED_MENU = {
    "inline_keyboard": [
        [
            {"text": "💰 Oportunidades", "callback_data": "advanced:general"},
            {"text": "📦 Revenda Amazon", "callback_data": "advanced:amazon"},
        ],
        [
            {"text": "🏪 Fornecedores", "callback_data": "advanced:suppliers"},
            {"text": "📊 Marketplaces", "callback_data": "advanced:marketplaces"},
        ],
        [
            {"text": "🔍 Análise profunda", "callback_data": "advanced:deep_product"},
            {"text": "🔄 Atualizar análise", "callback_data": "advanced:update"},
        ],
        [{"text": "🏠 Menu principal", "callback_data": "menu:main"}],
    ]
}


def _confirmation_menu() -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "✅ Iniciar pesquisa", "callback_data": "confirm:yes"},
                {"text": "❌ Cancelar", "callback_data": "confirm:no"},
            ]
        ]
    }


def _account_menu() -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "📍 Alterar CEP", "callback_data": "menu:cep"},
                {"text": "⭐ Ver Premium", "callback_data": "menu:plans"},
            ],
            [
                {"text": "🕘 Histórico", "callback_data": "menu:history"},
                {"text": "📤 Compartilhar", "callback_data": "menu:share"},
            ],
            [
                {"text": "💬 Suporte", "callback_data": "license:contact"},
                {"text": "🏠 Menu", "callback_data": "menu:main"},
            ],
        ]
    }


def _plans_menu(settings: Settings) -> dict[str, Any]:
    first_button: dict[str, str]
    if settings.license_payment_url.startswith("https://"):
        first_button = {"text": "💳 Ativar por R$ 9,90", "url": settings.license_payment_url}
    else:
        first_button = {"text": "💳 Ativar por R$ 9,90", "callback_data": "license:contact"}
    return {
        "inline_keyboard": [
            [first_button],
            [{"text": "🏠 Menu principal", "callback_data": "menu:main"}],
        ]
    }


async def _send_main(chat_id: int, user: Any, settings: Settings) -> None:
    await send_message_async(
        chat_id,
        "🏠 MENU PRINCIPAL\n\nEscolha uma opção. O bot pesquisa preços atuais, calcula ou estima o frete para seu CEP e entrega links diretos das ofertas.",
        reply_markup=_main_menu(user, settings),
    )


async def _send_welcome(chat_id: int, user: Any, settings: Settings, redis: Redis) -> None:
    if not user.postal_code:
        redis.setex(f"awaiting:{user.telegram_id}", 900, "cep")
        await send_message_async(
            chat_id,
            f"🔥 Bem-vindo ao {settings.app_name}!\n\n"
            "Eu pesquiso promoções, comparo preços e verifico se o desconto é real.\n\n"
            "📍 Para considerar o frete, envie primeiro o CEP de entrega.\n"
            "Exemplo: 72400-000",
        )
        return
    await send_message_async(
        chat_id,
        f"🔥 Bem-vindo ao {settings.app_name}!\n\n"
        "Encontre ofertas reais, compare preços e abra os produtos diretamente nos botões. A área de revenda fica no Premium.\n\n"
        f"{_status_text(user)}",
        reply_markup=_main_menu(user, settings),
    )


async def _send_help(chat_id: int, user: Any, settings: Settings) -> None:
    text = (
        "❓ COMO FUNCIONA\n\n"
        "🔥 Promoções agora\nPesquisa ofertas recentes e verifica o desconto real.\n\n"
        "🔎 Buscar produto\nCompara um produto por nome, link ou foto.\n\n"
        "🏷️ Cupons\nProcura cupons, Pix e frete promocional.\n\n"
        "📍 CEP\nÉ utilizado como destino para confirmar ou estimar o frete.\n\n"
        "🔒 Revenda avançada\nInclui fornecedores, Amazon, marketplaces, margem, ROI e cenários de risco. Requer Premium.\n\n🛒 Links diretos\nOs produtos aprovados aparecem em botões para abrir a oferta na loja."
    )
    await send_message_async(chat_id, text, reply_markup=_main_menu(user, settings))


async def _send_plans(chat_id: int, user: Any, settings: Settings) -> None:
    price = _format_brl(settings.premium_monthly_price_brl)
    text = (
        "⭐ PLANOS DO CAÇADOR DE PROMOÇÕES\n\n"
        "🆓 GRATUITO\n"
        f"• {settings.basic_monthly_quota} consultas por mês\n"
        "• Promoções atuais e cupons\n"
        "• Busca por nome, link ou foto\n"
        "• Comparação de preços\n"
        "• Frete pelo CEP\n"
        "• Links diretos para os produtos\n\n"
        "💎 PREMIUM ILIMITADO\n"
        "• Consultas ilimitadas para uso individual\n"
        "• Tudo do Gratuito\n"
        "• Revenda na Amazon, Mercado Livre e Shopee\n"
        "• Pesquisa de fornecedores e atacadistas\n"
        "• Margem líquida, ROI e ponto de equilíbrio\n"
        "• Cenários de risco e análises profundas\n"
        "• Histórico ampliado\n\n"
        f"💳 Apenas {price} por 30 dias\n"
        "🔐 Sem fidelidade. Renovação conforme sua forma de cobrança.\n\n"
        f"Seu plano atual: {_plan_label(user.plan)}"
    )
    await send_message_async(chat_id, text, reply_markup=_plans_menu(settings))


async def _save_cep_from_message(
    *,
    chat_id: int,
    telegram_user: dict[str, Any],
    value: str,
    redis: Redis,
    settings: Settings,
) -> bool:
    cep = normalize_cep(value)
    if not cep:
        await send_message_async(chat_id, "⚠️ CEP inválido. Envie 8 números, por exemplo: 72400-000.")
        return False
    info = await lookup_cep(cep)
    if info is None:
        await send_message_async(chat_id, "⚠️ CEP não localizado. Confira os números e tente novamente.")
        return False
    with session_scope() as session:
        user = upsert_user(session, telegram_user, settings)
        user = save_postal_code(session, user.id, info)
    redis.delete(f"awaiting:{telegram_user['id']}")
    location = format_cep(info.cep)
    if info.city and info.state:
        location += f" • {info.city}/{info.state}"
    verification = "✅ CEP confirmado" if info.verified else "✅ CEP salvo"
    await send_message_async(
        chat_id,
        f"{verification}: {location}\n\nO frete será pesquisado ou estimado para esse destino.",
        reply_markup=_main_menu(user, settings),
    )
    return True


async def _send_history(chat_id: int, user: Any, settings: Settings) -> None:
    limit = 20 if is_licensed(user, settings) else 8
    with session_scope() as session:
        items = recent_requests(session, user.id, limit)
    if not items:
        await send_message_async(chat_id, "🕘 Você ainda não realizou pesquisas.", reply_markup=_main_menu(user, settings))
        return
    lines = ["🕘 PESQUISAS RECENTES", ""]
    for item in items:
        date = item.created_at.strftime("%d/%m %H:%M")
        icon = {"completed": "✅", "failed": "⚠️", "processing": "🔍", "queued": "⏳"}.get(item.status, "•")
        lines.append(f"{icon} {date} • {MODE_LABELS.get(item.command, item.command)} • {item.id[:8]}")
    await send_message_async(chat_id, "\n".join(lines), reply_markup=_main_menu(user, settings))


async def _prepare_research(
    *,
    chat_id: int,
    telegram_user: dict[str, Any],
    command: str,
    depth: str,
    query: str,
    file_id: str | None,
    redis: Redis,
    settings: Settings,
    auto_start: bool = True,
) -> None:
    with session_scope() as session:
        user = upsert_user(session, telegram_user, settings)
        allowed, reason = validate_access(user, settings)
        feature_allowed, feature_reason = validate_feature_access(user, command, depth, settings)
    if not user.postal_code:
        redis.setex(f"awaiting:{telegram_user['id']}", 900, "cep")
        redis.setex(
            f"after_cep:{telegram_user['id']}",
            900,
            json.dumps({"command": command, "depth": depth, "query": query, "file_id": file_id}),
        )
        await send_message_async(chat_id, "📍 Antes da pesquisa, envie o CEP de entrega para calcular ou estimar o frete.")
        return
    if not allowed:
        await send_message_async(chat_id, f"⚠️ {reason}", reply_markup=_plans_menu(settings))
        return
    if not feature_allowed:
        await send_message_async(
            chat_id,
            f"🔒 {feature_reason}\n\nAtive o Premium para acessar revenda, fornecedores, marketplaces e análises profundas.",
            reply_markup=_plans_menu(settings),
        )
        return

    payload = {"command": command, "depth": depth, "query": query or "Usar parâmetros padrão.", "file_id": file_id}
    if auto_start:
        await _queue_research(
            chat_id=chat_id,
            message_id=None,
            telegram_user=telegram_user,
            command=payload["command"],
            depth=payload["depth"],
            query=payload["query"],
            file_id=payload.get("file_id"),
            settings=settings,
        )
        return

    redis.setex(f"pending_research:{telegram_user['id']}", 900, json.dumps(payload))
    await send_message_async(
        chat_id,
        f"🔎 CONFIRMAR PESQUISA\n\n"
        f"Tipo: {MODE_LABELS.get(command, command)}\n"
        f"CEP: {format_cep(user.postal_code)}\n"
        f"Consumo: 1 consulta\n"
        f"Saldo atual: {remaining_quota(user)}\n\n"
        "A consulta é devolvida automaticamente se houver falha técnica.",
        reply_markup=_confirmation_menu(),
    )



async def _queue_research(
    *,
    chat_id: int,
    message_id: int | None,
    telegram_user: dict[str, Any],
    command: str,
    depth: str,
    query: str,
    file_id: str | None,
    settings: Settings,
) -> None:
    with session_scope() as session:
        user = upsert_user(session, telegram_user, settings)
        reserved, reason, user = reserve_quota(
            session,
            user.id,
            settings=settings,
            command=command,
            depth=depth,
            max_active_requests=settings.max_active_requests_per_user,
        )
        if not reserved:
            await send_message_async(chat_id, f"⚠️ {reason}", reply_markup=_plans_menu(settings))
            return
        request = create_research_request(
            session,
            user_id=user.id,
            chat_id=chat_id,
            message_id=message_id,
            command=command,
            mode=depth,
            query=query or "Usar parâmetros padrão.",
            input_type="image" if file_id else "text",
            telegram_file_id=file_id,
        )
        request_id = request.id
        remaining = remaining_quota(user)

    try:
        celery_app.send_task("app.tasks.process_research", args=[request_id])
    except Exception:
        logger.exception("Falha ao enviar pesquisa para a fila")
        from app.repositories import get_request, refund_quota

        with session_scope() as session:
            request = get_request(session, request_id)
            if request:
                request.status = "failed"
                request.error_message = "Falha ao enviar a tarefa para a fila"
                refund_quota(session, request.user_id)
        await send_message_async(chat_id, "⚠️ A fila está indisponível. O crédito foi devolvido.")
        return

    quota_line = "Consultas: ilimitadas" if remaining == "ilimitada" else f"Consultas gratuitas restantes: {remaining}"
    await send_message_async(
        chat_id,
        f"✅ Pesquisa recebida\n"
        f"Protocolo: {request_id[:8]}\n"
        f"{quota_line}",
    )



async def _handle_admin(text: str, chat_id: int, telegram_id: int, settings: Settings) -> bool:
    if not _is_admin(telegram_id, settings):
        return False
    parts = text.split()
    command = parts[0].lower()
    valid_plans = {"basico", "pro", "premium", "empresarial", "admin"}

    try:
        if command in {"/admin_ativar", "/admin_licenca"}:
            if command == "/admin_licenca":
                if len(parts) < 2:
                    await send_message_async(chat_id, "Uso: /admin_licenca ID [dias] [quota]")
                    return True
                target = int(parts[1])
                plan = "pro"
                days = int(parts[2]) if len(parts) >= 3 else 30
                quota = int(parts[3]) if len(parts) >= 4 else None
            else:
                if len(parts) < 3:
                    await send_message_async(chat_id, "Uso: /admin_ativar ID plano [dias] [quota]")
                    return True
                target = int(parts[1])
                plan = parts[2].lower()
                days = int(parts[3]) if len(parts) >= 4 else 30
                quota = int(parts[4]) if len(parts) >= 5 else None
            if plan not in valid_plans:
                await send_message_async(chat_id, "Plano inválido. Use basico, pro, premium, empresarial ou admin.")
                return True
            if days < 0 or (quota is not None and quota < 0):
                await send_message_async(chat_id, "Dias e quota não podem ser negativos.")
                return True
            with session_scope() as session:
                user = activate_user(session, target, plan, days, quota, settings)
                status = _status_text(user) if user else ""
            if not user:
                await send_message_async(chat_id, "Usuário não localizado. Ele precisa iniciar o bot primeiro.")
                return True
            await send_message_async(chat_id, f"✅ Acesso atualizado para {target}.\n\n{status}")
            try:
                await send_message_async(target, f"⭐ Sua licença foi ativada.\n\n{status}", reply_markup=_main_menu(user, settings))
            except Exception:
                logger.exception("Acesso ativado, mas o aviso ao usuário %s falhou", target)
            return True

        if command == "/admin_bloquear":
            if len(parts) != 2:
                await send_message_async(chat_id, "Uso: /admin_bloquear ID")
                return True
            target = int(parts[1])
            with session_scope() as session:
                user = block_user(session, target)
            await send_message_async(chat_id, "Usuário bloqueado." if user else "Usuário não localizado.")
            return True

        if command == "/admin_creditos":
            if len(parts) != 3:
                await send_message_async(chat_id, "Uso: /admin_creditos ID quantidade")
                return True
            target, credits = int(parts[1]), int(parts[2])
            with session_scope() as session:
                user = add_credits(session, target, credits)
                status = _status_text(user) if user else ""
            await send_message_async(chat_id, f"✅ Franquia atualizada.\n\n{status}" if user else "Usuário não localizado.")
            return True

        if command == "/admin_stats":
            with session_scope() as session:
                stats = service_stats(session)
            await send_message_async(
                chat_id,
                "📊 INDICADORES DO SERVIÇO\n"
                f"Usuários: {stats['users']}\n"
                f"Ativos: {stats['active_users']}\n"
                f"Premium: {stats['premium_users']}\n"
                f"Pesquisas: {stats['total_requests']}\n"
                f"Concluídas: {stats['completed']}\n"
                f"Falhas: {stats['failed']}\n"
                f"Tokens de entrada: {stats['input_tokens']}\n"
                f"Tokens de saída: {stats['output_tokens']}\n"
                f"Buscas web: {stats['web_search_calls']}",
            )
            return True
    except ValueError:
        await send_message_async(chat_id, "Parâmetros inválidos. Confira ID, dias e quota.")
        return True

    return False


async def handle_callback(update: dict[str, Any], redis: Redis, settings: Settings) -> None:
    callback = update.get("callback_query") or {}
    callback_id = callback.get("id")
    data = callback.get("data", "")
    message = callback.get("message") or {}
    telegram_user = callback.get("from") or {}
    chat = message.get("chat") or {}
    chat_id = int(chat.get("id", 0))
    telegram_id = int(telegram_user.get("id", 0))

    if callback_id:
        await answer_callback_query(callback_id)
    if not chat_id or not telegram_id:
        return

    with session_scope() as session:
        user = upsert_user(session, telegram_user, settings)

    if data == "menu:main":
        await _send_main(chat_id, user, settings)
        return
    if data in {"menu:promotions", "menu:categories"}:
        await send_message_async(chat_id, "🔥 Escolha uma categoria para pesquisar promoções:", reply_markup=PROMOTIONS_MENU)
        return
    if data == "menu:search":
        redis.setex(f"awaiting:{telegram_id}", 900, "product")
        await send_message_async(
            chat_id,
            "🔎 Qual produto você procura?\n\nEnvie o nome, link ou uma foto. Exemplo:\nAir fryer Mondial 5 litros 220V",
        )
        return
    if data == "menu:coupons":
        await send_message_async(chat_id, "🏷️ Escolha o tipo de cupom ou desconto:", reply_markup=COUPONS_MENU)
        return
    if data == "menu:history":
        await _send_history(chat_id, user, settings)
        return
    if data == "menu:account":
        await send_message_async(chat_id, f"👤 MINHA CONTA\n\n{_status_text(user)}", reply_markup=_account_menu())
        return
    if data == "menu:cep":
        redis.setex(f"awaiting:{telegram_id}", 900, "cep")
        await send_message_async(chat_id, "📍 Envie o novo CEP de entrega. Exemplo: 72400-000")
        return
    if data == "menu:plans":
        await _send_plans(chat_id, user, settings)
        return
    if data == "menu:help":
        await _send_help(chat_id, user, settings)
        return
    if data == "menu:share":
        if settings.share_url:
            await send_message_async(
                chat_id,
                "📤 Compartilhe o Caçador de Promoções com seus amigos:",
                reply_markup={"inline_keyboard": [[{"text": "📤 Enviar para um contato", "url": settings.share_url}], [{"text": "🏠 Menu", "callback_data": "menu:main"}]]},
            )
        else:
            await send_message_async(
                chat_id,
                "📤 Configure TELEGRAM_BOT_USERNAME para habilitar o link de compartilhamento.",
                reply_markup=_main_menu(user, settings),
            )
        return
    if data == "license:contact":
        await send_message_async(
            chat_id,
            f"💳 ATIVAÇÃO DA LICENÇA\n\nEnvie ao atendimento o seu ID: {telegram_id}\n\n{settings.sales_message}\n{settings.support_contact}",
            reply_markup=_plans_menu(settings),
        )
        return
    if data == "menu:advanced":
        if not is_licensed(user, settings):
            await send_message_async(
                chat_id,
                "🔒 REVENDA AVANÇADA\n\n"
                "Essa área calcula margem, ROI, ponto de equilíbrio, fornecedores e comparação entre marketplaces.\n\n"
                "Ative o Premium ilimitado por R$ 9,90 para desbloquear.",
                reply_markup=_plans_menu(settings),
            )
            return
        await send_message_async(chat_id, "🧰 REVENDA AVANÇADA\n\nEscolha uma ferramenta:", reply_markup=ADVANCED_MENU)
        return

    if data.startswith("promo:"):
        key = data.split(":", 1)[1]
        category = PROMOTION_CATEGORIES.get(key, key)
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command="promotions",
            depth="express",
            query=f"Pesquise as melhores promoções atuais em {category}. Priorize economia para compra própria.",
            file_id=None,
            redis=redis,
            settings=settings,
        )
        return

    if data.startswith("coupon:"):
        key = data.split(":", 1)[1]
        category = COUPON_CATEGORIES.get(key, key)
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command="promotions",
            depth="express",
            query=f"Pesquise {category}, confirmando regras, validade, valor mínimo, frete e lojas confiáveis.",
            file_id=None,
            redis=redis,
            settings=settings,
        )
        return

    advanced_waiting = {
        "advanced:general": ("general", "express"),
        "advanced:amazon": ("amazon", "express"),
        "advanced:suppliers": ("suppliers", "express"),
        "advanced:marketplaces": ("marketplaces", "express"),
        "advanced:deep_product": ("product", "deep"),
        "advanced:update": ("update", "deep"),
    }
    if data in advanced_waiting:
        command, depth = advanced_waiting[data]
        redis.setex(f"awaiting:{telegram_id}", 900, f"research|{command}|{depth}")
        await send_message_async(chat_id, PROMPTS_BY_MODE[command])
        return

    if data == "confirm:no":
        redis.delete(f"pending_research:{telegram_id}")
        await send_message_async(chat_id, "❌ Pesquisa cancelada. Nenhum crédito foi utilizado.", reply_markup=_main_menu(user, settings))
        return
    if data == "confirm:yes":
        raw = redis.get(f"pending_research:{telegram_id}")
        if not raw:
            await send_message_async(chat_id, "⚠️ A confirmação expirou. Inicie a pesquisa novamente.", reply_markup=_main_menu(user, settings))
            return
        redis.delete(f"pending_research:{telegram_id}")
        payload = json.loads(raw.decode() if isinstance(raw, bytes) else raw)
        await _queue_research(
            chat_id=chat_id,
            message_id=message.get("message_id"),
            telegram_user=telegram_user,
            command=payload["command"],
            depth=payload["depth"],
            query=payload["query"],
            file_id=payload.get("file_id"),
            settings=settings,
        )
        return


async def handle_message(update: dict[str, Any], redis: Redis, settings: Settings) -> None:
    message = update.get("message") or {}
    chat = message.get("chat") or {}
    telegram_user = message.get("from") or {}
    if chat.get("type") != "private" or not telegram_user:
        return

    chat_id = int(chat["id"])
    telegram_id = int(telegram_user["id"])
    if not within_rate_limit(redis, telegram_id, settings):
        await send_message_async(chat_id, "⚠️ Muitas mensagens em pouco tempo. Aguarde e tente novamente.")
        return

    text = (message.get("text") or message.get("caption") or "").strip()
    photos = message.get("photo") or []
    file_id = photos[-1]["file_id"] if photos else None

    with session_scope() as session:
        user = upsert_user(session, telegram_user, settings)

    if text.startswith("/admin_") and await _handle_admin(text, chat_id, telegram_id, settings):
        return
    if text.startswith("/start") or text.startswith("/menu"):
        await _send_welcome(chat_id, user, settings, redis)
        return
    if text.startswith("/ajuda"):
        await _send_help(chat_id, user, settings)
        return
    if text.startswith("/id"):
        await send_message_async(chat_id, f"🪪 Seu ID do Telegram é: {telegram_id}")
        return
    if text.startswith("/planos"):
        await _send_plans(chat_id, user, settings)
        return
    if text.startswith("/cep"):
        value = text.removeprefix("/cep").strip()
        if not value:
            redis.setex(f"awaiting:{telegram_id}", 900, "cep")
            await send_message_async(chat_id, "📍 Envie seu CEP. Exemplo: 72400-000")
            return
        await _save_cep_from_message(
            chat_id=chat_id,
            telegram_user=telegram_user,
            value=value,
            redis=redis,
            settings=settings,
        )
        return
    if text.startswith("/status"):
        with session_scope() as session:
            current = upsert_user(session, telegram_user, settings)
            active = active_request_count(session, current.id)
        await send_message_async(chat_id, f"🔍 Pesquisas em andamento: {active}\n\n{_status_text(current)}", reply_markup=_account_menu())
        return
    if text.startswith("/historico"):
        await _send_history(chat_id, user, settings)
        return

    waiting_raw = redis.get(f"awaiting:{telegram_id}")
    waiting = waiting_raw.decode() if isinstance(waiting_raw, bytes) else str(waiting_raw or "")
    if waiting == "cep":
        saved = await _save_cep_from_message(
            chat_id=chat_id,
            telegram_user=telegram_user,
            value=text,
            redis=redis,
            settings=settings,
        )
        if saved:
            raw_after = redis.get(f"after_cep:{telegram_id}")
            if raw_after:
                redis.delete(f"after_cep:{telegram_id}")
                payload = json.loads(raw_after.decode() if isinstance(raw_after, bytes) else raw_after)
                await _prepare_research(
                    chat_id=chat_id,
                    telegram_user=telegram_user,
                    command=payload["command"],
                    depth=payload["depth"],
                    query=payload["query"],
                    file_id=payload.get("file_id"),
                    redis=redis,
                    settings=settings,
                )
        return

    if file_id:
        command, depth = "product", "express"
        if waiting.startswith("research|"):
            _, command, depth = waiting.split("|", 2)
            redis.delete(f"awaiting:{telegram_id}")
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command=command,
            depth=depth,
            query=text or "Analise o produto apresentado na imagem.",
            file_id=file_id,
            redis=redis,
            settings=settings,
        )
        return

    if waiting:
        redis.delete(f"awaiting:{telegram_id}")
        if waiting == "product":
            command, depth = "product", "express"
        elif waiting.startswith("research|"):
            _, command, depth = waiting.split("|", 2)
        else:
            command, depth = waiting, "express"
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command=command,
            depth=depth,
            query=text,
            file_id=None,
            redis=redis,
            settings=settings,
        )
        return

    if text.startswith("/pesquisar"):
        query = text.removeprefix("/pesquisar").strip()
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command="promotions",
            depth="express",
            query=query or "Pesquise promoções atuais em todas as categorias.",
            file_id=None,
            redis=redis,
            settings=settings,
        )
        return

    command, query, depth = detect_research_command(text)
    if command:
        await _prepare_research(
            chat_id=chat_id,
            telegram_user=telegram_user,
            command=command,
            depth=depth,
            query=query,
            file_id=None,
            redis=redis,
            settings=settings,
        )
        return

    await send_message_async(
        chat_id,
        "Escolha uma opção no menu. Assim nenhuma pesquisa é consumida por engano.",
        reply_markup=_main_menu(user, settings),
    )


async def handle_update(update: dict[str, Any], redis: Redis, settings: Settings) -> None:
    if "callback_query" in update:
        await handle_callback(update, redis, settings)
    elif "message" in update:
        await handle_message(update, redis, settings)
