# Tutorial de instalação no Render

## Alerta de segurança

O token do Telegram é uma senha com controle total do bot. Como ele foi exibido em uma imagem/conversa, revogue-o no @BotFather antes do deploy e gere um novo token. Não reutilize o token exposto.

No @BotFather:

1. Abra `/mybots`.
2. Selecione o bot.
3. Entre em **API Token**.
4. Revogue o token atual e gere outro.
5. Guarde o novo token apenas no painel de variáveis do Render.

## O bot utiliza ENV?

Sim. Em produção, o bot lê configurações e segredos pelas **Environment Variables** do Render.

O arquivo `.env` é usado apenas em desenvolvimento local. No Render:

- não crie `ENV_FILE`;
- não envie `.env` ao GitHub;
- não grave tokens dentro do código;
- não use as chaves `BOT_TOKEN` ou `ADMIN_CHAT_ID` neste projeto.

As chaves corretas são `TELEGRAM_BOT_TOKEN` e `ADMIN_USER_IDS`.

## 1. Preparar o GitHub

1. Baixe e descompacte o projeto.
2. Crie um repositório privado no GitHub.
3. Envie o **conteúdo interno** da pasta `gpt_cacador_revenda` para a raiz do repositório.
4. Confirme que `render.yaml`, `requirements.txt`, `Dockerfile` e a pasta `app` aparecem diretamente na raiz.
5. Não envie `.env` nem qualquer token.

Estrutura correta:

```text
seu-repositorio/
├── app/
├── render.yaml
├── requirements.txt
├── Dockerfile
└── README.md
```

## 2. Criar a chave da OpenAI

1. Entre na plataforma da OpenAI.
2. Crie um projeto para o bot.
3. Gere uma API key do projeto.
4. Ative faturamento e defina limite de gasto compatível com o teste.
5. Guarde a chave para preencher `OPENAI_API_KEY` no Render.

A assinatura do ChatGPT não substitui a cobrança da API.

## 3. Gerar o segredo do webhook

No seu computador, execute:

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

Use a saída em `TELEGRAM_WEBHOOK_SECRET`. O valor deve ter pelo menos 16 caracteres e conter apenas letras, números, `_` e `-`.

## 4. Criar o Blueprint no Render

1. Entre no painel do Render.
2. Clique em **New**.
3. Selecione **Blueprint**.
4. Conecte sua conta do GitHub.
5. Escolha o repositório do bot.
6. Confirme que o Render encontrou o arquivo `render.yaml`.
7. Clique para aplicar o Blueprint.

O Blueprint criará:

- `cacador-revenda-api`: serviço web FastAPI;
- `cacador-revenda-worker`: worker Celery;
- `cacador-revenda-db`: PostgreSQL;
- `cacador-revenda-queue`: Render Key Value/Redis.

Para operação comercial, utilize planos pagos no serviço web e no worker. Instâncias gratuitas são adequadas apenas para testes e podem reiniciar ou ficar indisponíveis.

## 5. Preencher as variáveis no Render

O Render solicitará variáveis secretas para o serviço web e para o worker. Use os mesmos valores nos dois serviços.

| Variável | Valor |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Novo token gerado pelo @BotFather |
| `TELEGRAM_WEBHOOK_SECRET` | Segredo aleatório criado no passo 3 |
| `OPENAI_API_KEY` | Chave do projeto da OpenAI |
| `ADMIN_USER_IDS` | Seu ID numérico do Telegram |
| `SUPPORT_CONTACT` | Ex.: `Atendimento: @seu_usuario` |
| `SALES_MESSAGE` | Ex.: `Ative o Premium por R$ 9,90. Fale com @seu_usuario.` |
| `LICENSE_PAYMENT_URL` | Link do checkout; pode ficar vazio inicialmente |
| `TELEGRAM_BOT_USERNAME` | Username do bot sem `@` |

Já estão configuradas no `render.yaml`:

```env
BASIC_MONTHLY_QUOTA=20
PRO_MONTHLY_QUOTA=0
PREMIUM_MONTHLY_PRICE_BRL=9.90
OPENAI_MODEL=gpt-5.6
```

O valor `0` no plano Premium significa franquia ilimitada no sistema, com proteção de uma pesquisa simultânea por usuário e rate limit.

O Render cria automaticamente `DATABASE_URL` e `REDIS_URL`. Não preencha essas duas manualmente.

`PUBLIC_BASE_URL` também não é necessário no Render, porque o código usa automaticamente `RENDER_EXTERNAL_HOSTNAME`.

## 6. Corrigir as variáveis mostradas em projetos antigos

Não use:

```env
ADMIN_CHAT_ID
BOT_TOKEN
ENV_FILE
```

Use:

```env
ADMIN_USER_IDS=<SEU_ID_NUMERICO>
TELEGRAM_BOT_TOKEN=<NOVO_TOKEN>
```

Não existe `ENV_FILE` no deploy do Render deste projeto.

## 7. Acompanhar o primeiro deploy

Abra os logs de `cacador-revenda-api`. O esperado é aparecer:

```text
Webhook e comandos do Telegram configurados
```

Abra os logs de `cacador-revenda-worker`. O esperado é o Celery indicar que está pronto para processar tarefas.

Teste o health check no navegador:

```text
https://SEU-SERVICO.onrender.com/health
```

Resposta esperada:

```json
{"status":"ok","database":"ok","queue":"ok"}
```

## 8. Testar no Telegram

1. Abra o bot.
2. Envie `/start`.
3. Informe o CEP solicitado.
4. Use os botões do menu.
5. Faça uma busca simples.
6. Confirme se o resultado mostra botões para abrir os produtos.
7. Envie `/admin_stats` para testar seu acesso administrativo.

O menu normal do usuário é totalmente conduzido por botões. Os comandos administrativos permanecem disponíveis somente para IDs cadastrados em `ADMIN_USER_IDS`.

## 9. Ativar um usuário Premium

O cliente precisa iniciar o bot ao menos uma vez. Depois, use:

```text
/admin_licenca ID_DO_USUARIO 30
```

Isso ativa o Premium por 30 dias. Para localizar o ID, o próprio usuário pode consultar a opção de conta ou enviar `/id`, conforme disponível no projeto.

## 10. Atualizar o bot depois

1. Altere os arquivos no GitHub.
2. Faça commit na branch conectada.
3. O Render executará novo deploy automaticamente.
4. Acompanhe os logs do web e do worker.

Alterações somente em variáveis podem ser feitas em **Environment** no Render. Depois, salve para disparar o redeploy.

## 11. Diagnóstico rápido

### Bot não responde

- Confirme se `cacador-revenda-api` está ativo.
- Confirme se o token foi preenchido com o nome `TELEGRAM_BOT_TOKEN`.
- Confirme se o mesmo `TELEGRAM_WEBHOOK_SECRET` está no web e no worker.
- Veja se o log registra a configuração do webhook.

### Pesquisa fica parada

- Confirme se `cacador-revenda-worker` está ativo.
- Confirme se o Key Value está disponível.
- Verifique `REDIS_URL` e `DATABASE_URL`, que devem ser vinculados automaticamente pelo Blueprint.

### OpenAI retorna erro

- Confirme `OPENAI_API_KEY`.
- Verifique faturamento e limite de gastos no projeto da API.
- Confirme se `OPENAI_MODEL` está disponível para sua organização.

### Administrador não é reconhecido

- Use `ADMIN_USER_IDS`, não `ADMIN_CHAT_ID`.
- Informe somente números, sem espaços extras.
- Para vários administradores, separe por vírgula.

Exemplo:

```env
ADMIN_USER_IDS=123456789,987654321
```

## 12. Segurança obrigatória

- Nunca envie token ou API key em mensagem, print, GitHub ou grupo.
- Use repositório privado.
- Revogue imediatamente qualquer credencial exposta.
- Configure limites de gasto na OpenAI.
- Faça backup do PostgreSQL antes de mudanças relevantes.
- Não use plano gratuito do Render como produção comercial.
