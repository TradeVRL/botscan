from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from redis import Redis
from sqlalchemy import text

from app.db import engine, init_db
from app.handlers import handle_update
from app.security import accept_update_once, valid_webhook_secret
from app.settings import get_settings
from app.telegram_api import set_commands, set_webhook

settings = get_settings()
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)
redis_client = Redis.from_url(settings.redis_url, decode_responses=False)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    redis_client.ping()
    try:
        await set_webhook()
        await set_commands()
        logger.info("Webhook e comandos do Telegram configurados")
    except Exception:
        logger.exception("Não foi possível configurar o Telegram na inicialização")
    yield
    redis_client.close()


app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    docs_url=None if settings.environment == "production" else "/docs",
    redoc_url=None,
    lifespan=lifespan,
)


@app.get("/", response_class=PlainTextResponse)
def root() -> str:
    return "Caçador de Promoções está online."


@app.get("/health")
def health() -> dict[str, str]:
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        redis_client.ping()
    except Exception as exc:
        logger.exception("Health check falhou")
        raise HTTPException(status_code=503, detail="Dependência indisponível") from exc
    return {"status": "ok", "database": "ok", "queue": "ok"}


@app.post(settings.telegram_webhook_path)
async def telegram_webhook(
    request: Request,
    x_telegram_bot_api_secret_token: str | None = Header(default=None),
) -> JSONResponse:
    if not valid_webhook_secret(x_telegram_bot_api_secret_token, settings):
        raise HTTPException(status_code=403, detail="Webhook inválido")
    update = await request.json()
    update_id = int(update.get("update_id", 0))
    if update_id and not accept_update_once(redis_client, update_id):
        return JSONResponse({"ok": True, "duplicate": True})
    try:
        await handle_update(update, redis_client, settings)
    except Exception:
        logger.exception("Falha ao processar atualização do Telegram")
    return JSONResponse({"ok": True})
