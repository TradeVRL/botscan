"""GPT Caçador de Oportunidades de Revenda."""
