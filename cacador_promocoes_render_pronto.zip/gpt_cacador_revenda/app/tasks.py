from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from celery.signals import worker_process_init

from app.celery_app import celery_app
from app.db import init_db, session_scope
from app.repositories import get_request, get_user_by_id, refund_quota, remaining_quota
from app.product_links import product_links_from_metadata, result_metadata_to_json
from app.research import run_research
from app.settings import get_settings
from app.telegram_api import (
    get_telegram_file,
    send_chat_action_sync,
    send_document_sync,
    send_message_sync,
)
from app.utils import MODE_LABELS, safe_filename

logger = logging.getLogger(__name__)
settings = get_settings()
PREMIUM_PLANS = {"pro", "premium", "empresarial", "admin"}


@worker_process_init.connect
def initialize_worker(**_: object) -> None:
    init_db()


def _result_menu(
    product_links: list[dict[str, str]],
    *,
    is_premium: bool,
) -> dict[str, Any]:
    rows: list[list[dict[str, str]]] = []
    for item in product_links[:8]:
        title = str(item.get("title") or "Acessar oferta")[:45]
        url = str(item.get("url") or "")
        if url.startswith("https://"):
            rows.append([{"text": f"🛒 {title}", "url": url}])

    rows.append(
        [
            {"text": "🔥 Nova pesquisa", "callback_data": "menu:promotions"},
            {"text": "🏠 Menu", "callback_data": "menu:main"},
        ]
    )
    if not is_premium:
        rows.append([{"text": "⭐ Premium ilimitado • R$ 9,90", "callback_data": "menu:plans"}])
    if settings.share_url:
        rows.append([{"text": "📤 Compartilhar o bot", "url": settings.share_url}])
    return {"inline_keyboard": rows}


def _deliver_report(
    chat_id: int,
    request_id: str,
    command: str,
    result_text: str,
    product_links: list[dict[str, str]],
    *,
    is_premium: bool,
) -> None:
    menu = _result_menu(product_links, is_premium=is_premium)
    if len(result_text) <= 14000:
        send_message_sync(chat_id, result_text, reply_markup=menu)
        return
    preview = result_text[:7800].rsplit("\n", 1)[0]
    send_message_sync(chat_id, preview + "\n\n📄 O relatório completo foi enviado no arquivo abaixo.")
    filename = f"{safe_filename(command)}_{request_id[:8]}.txt"
    send_document_sync(chat_id, filename, result_text, "Relatório completo da pesquisa")
    send_message_sync(
        chat_id,
        "🛒 Use os botões abaixo para abrir as ofertas encontradas.",
        reply_markup=menu,
    )


def _completion_footer(user: Any) -> str:
    if user.plan in PREMIUM_PLANS:
        return "✅ Pesquisa concluída • Premium com consultas ilimitadas."

    remaining = int(remaining_quota(user))
    text = f"✅ Pesquisa concluída • {remaining} consulta(s) gratuita(s) restante(s) neste mês."
    if remaining <= 5:
        text += "\n⭐ O Premium custa R$ 9,90 e libera consultas ilimitadas e revenda avançada."
    return text


@celery_app.task(name="app.tasks.process_research", bind=True, max_retries=2)
def process_research(self, request_id: str) -> None:
    with session_scope() as session:
        request = get_request(session, request_id)
        if request is None or request.status == "completed":
            return
        if request.started_at is None:
            request.started_at = datetime.now(timezone.utc)
        request.status = "processing"
        chat_id = request.telegram_chat_id
        command = request.command
        depth = request.mode
        query = request.query
        file_id = request.telegram_file_id
        user_id = request.user_id
        user = get_user_by_id(session, user_id)
        destination_cep = user.postal_code if user else ""
        destination_region = ""
        is_premium = bool(user and user.plan in PREMIUM_PLANS)
        if user and user.postal_city and user.postal_state:
            destination_region = f"{user.postal_city}/{user.postal_state}"
        saved_result = request.result_text
        saved_links = product_links_from_metadata(request.sources_json)

    try:
        product_links = saved_links
        if not saved_result:
            if self.request.retries == 0:
                send_chat_action_sync(chat_id, "typing")
                send_message_sync(
                    chat_id,
                    f"🔍 Pesquisa iniciada: {MODE_LABELS.get(command, command)}\n"
                    f"📍 CEP de destino: {destination_cep or 'não informado'}\n"
                    "Estou comparando preços, frete, cupons e fontes.",
                )
            image_bytes = get_telegram_file(file_id) if file_id else None
            result = run_research(
                settings=settings,
                command=command,
                depth=depth,
                query=query,
                image_bytes=image_bytes,
                destination_cep=destination_cep or "",
                destination_region=destination_region,
            )
            saved_result = result.text
            product_links = result.product_links
            with session_scope() as session:
                request = get_request(session, request_id)
                if request is None:
                    return
                request.status = "delivering"
                request.result_text = result.text
                request.sources_json = result_metadata_to_json(result.sources, result.product_links)
                request.openai_response_id = result.response_id
                request.input_tokens = result.input_tokens
                request.output_tokens = result.output_tokens
                request.web_search_calls = result.web_search_calls
        else:
            with session_scope() as session:
                request = get_request(session, request_id)
                if request:
                    request.status = "delivering"

        with session_scope() as session:
            current_user = get_user_by_id(session, user_id)
            footer = _completion_footer(current_user) if current_user else "✅ Pesquisa concluída."

        _deliver_report(
            chat_id,
            request_id,
            command,
            saved_result.rstrip() + "\n\n" + footer,
            product_links,
            is_premium=is_premium,
        )

        with session_scope() as session:
            request = get_request(session, request_id)
            if request is None:
                return
            request.status = "completed"
            request.completed_at = datetime.now(timezone.utc)
    except Exception as exc:
        logger.exception("Falha na pesquisa ou entrega %s", request_id)
        if self.request.retries < self.max_retries:
            raise self.retry(exc=exc, countdown=20 * (self.request.retries + 1))

        with session_scope() as session:
            request = get_request(session, request_id)
            had_result = bool(request and request.result_text)
            if request:
                request.status = "failed"
                request.error_message = str(exc)[:4000]
                request.completed_at = datetime.now(timezone.utc)
                refund_quota(session, request.user_id)
        try:
            message = (
                "A pesquisa foi concluída, mas não foi possível entregar o relatório. "
                if had_result
                else "Não foi possível concluir esta pesquisa. "
            )
            send_message_sync(
                chat_id,
                message
                + "A consulta foi devolvida à sua franquia. Tente novamente ou encaminhe o protocolo ao suporte.",
            )
        except Exception:
            logger.exception("Também não foi possível comunicar a falha ao usuário %s", chat_id)
