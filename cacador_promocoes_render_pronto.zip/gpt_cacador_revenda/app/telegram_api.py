from __future__ import annotations

import io
import logging
from typing import Any

import httpx

from app.settings import get_settings
from app.utils import split_text

logger = logging.getLogger(__name__)
settings = get_settings()
BASE_API_URL = f"https://api.telegram.org/bot{settings.telegram_bot_token}"
BASE_FILE_URL = f"https://api.telegram.org/file/bot{settings.telegram_bot_token}"


class TelegramAPIError(RuntimeError):
    pass


def _check_response(response: httpx.Response) -> dict[str, Any]:
    response.raise_for_status()
    payload = response.json()
    if not payload.get("ok"):
        raise TelegramAPIError(str(payload))
    return payload


async def async_call(method: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(f"{BASE_API_URL}/{method}", json=payload or {})
    return _check_response(response)


def sync_call(method: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    with httpx.Client(timeout=30) as client:
        response = client.post(f"{BASE_API_URL}/{method}", json=payload or {})
    return _check_response(response)


async def set_webhook() -> None:
    if not settings.base_url:
        logger.warning("PUBLIC_BASE_URL ausente; webhook não configurado automaticamente")
        return
    await async_call(
        "setWebhook",
        {
            "url": f"{settings.base_url}{settings.telegram_webhook_path}",
            "secret_token": settings.telegram_webhook_secret,
            "allowed_updates": ["message", "callback_query"],
            "drop_pending_updates": False,
        },
    )


async def set_commands() -> None:
    # A experiência normal é conduzida por botões. Os dois comandos abaixo
    # permanecem apenas como porta de entrada e recuperação do menu.
    commands = [
        {"command": "start", "description": "Iniciar o Caçador de Promoções"},
        {"command": "menu", "description": "Abrir o menu principal"},
    ]
    await async_call("setMyCommands", {"commands": commands})
    await async_call("setChatMenuButton", {"menu_button": {"type": "commands"}})



async def send_message_async(
    chat_id: int,
    text: str,
    *,
    reply_markup: dict[str, Any] | None = None,
    disable_web_page_preview: bool = True,
) -> None:
    chunks = split_text(text)
    for index, chunk in enumerate(chunks):
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": chunk,
            "link_preview_options": {"is_disabled": disable_web_page_preview},
        }
        if index == len(chunks) - 1 and reply_markup:
            payload["reply_markup"] = reply_markup
        await async_call("sendMessage", payload)


def send_message_sync(
    chat_id: int,
    text: str,
    *,
    reply_markup: dict[str, Any] | None = None,
    disable_web_page_preview: bool = True,
) -> None:
    chunks = split_text(text)
    for index, chunk in enumerate(chunks):
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": chunk,
            "link_preview_options": {"is_disabled": disable_web_page_preview},
        }
        if index == len(chunks) - 1 and reply_markup:
            payload["reply_markup"] = reply_markup
        sync_call("sendMessage", payload)


def send_chat_action_sync(chat_id: int, action: str = "typing") -> None:
    sync_call("sendChatAction", {"chat_id": chat_id, "action": action})


async def answer_callback_query(callback_query_id: str, text: str = "") -> None:
    await async_call("answerCallbackQuery", {"callback_query_id": callback_query_id, "text": text})


def get_telegram_file(file_id: str) -> bytes:
    payload = sync_call("getFile", {"file_id": file_id})
    file_path = payload["result"]["file_path"]
    with httpx.Client(timeout=60) as client:
        response = client.get(f"{BASE_FILE_URL}/{file_path}")
        response.raise_for_status()
        return response.content


def send_document_sync(chat_id: int, filename: str, content: str, caption: str = "") -> None:
    files = {"document": (filename, io.BytesIO(content.encode("utf-8")), "text/plain")}
    data = {"chat_id": str(chat_id), "caption": caption[:1024]}
    with httpx.Client(timeout=60) as client:
        response = client.post(f"{BASE_API_URL}/sendDocument", data=data, files=files)
    _check_response(response)
