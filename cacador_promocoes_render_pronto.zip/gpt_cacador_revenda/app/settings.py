from __future__ import annotations

import os
from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Caçador de Promoções"
    environment: Literal["development", "production", "test"] = "development"
    log_level: str = "INFO"
    timezone: str = "America/Sao_Paulo"

    telegram_bot_token: str = Field(min_length=20)
    telegram_webhook_secret: str = Field(min_length=16, max_length=256)
    telegram_webhook_path: str = "/telegram/webhook"
    admin_user_ids: str = ""
    support_contact: str = "Atendimento: @seu_usuario"
    sales_message: str = "Para ativar a licença Premium, fale com o atendimento."
    license_payment_url: str = ""
    telegram_bot_username: str = ""

    openai_api_key: str = Field(min_length=20)
    openai_model: str = "gpt-5.6"
    openai_max_output_tokens: int = 7000
    openai_timeout_seconds: int = 420

    database_url: str
    redis_url: str
    public_base_url: str = ""

    # Plano Básico gratuito e licença Premium.
    basic_monthly_quota: int = 20
    pro_monthly_quota: int = 0
    enterprise_monthly_quota: int = 0
    premium_monthly_price_brl: float = 9.90

    max_active_requests_per_user: int = 1
    rate_limit_requests: int = 8
    rate_limit_window_seconds: int = 60

    default_capital_brl: int = 5000
    default_margin_percent: int = 20
    default_roi_percent: int = 25
    default_max_product_allocation_percent: int = 25

    @field_validator("telegram_webhook_secret")
    @classmethod
    def validate_webhook_secret(cls, value: str) -> str:
        allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
        if any(char not in allowed for char in value):
            raise ValueError("TELEGRAM_WEBHOOK_SECRET aceita apenas letras, números, _ e -")
        return value

    @property
    def admin_ids(self) -> set[int]:
        values: set[int] = set()
        for item in self.admin_user_ids.split(","):
            item = item.strip()
            if item:
                values.add(int(item))
        return values

    @property
    def normalized_database_url(self) -> str:
        url = self.database_url
        if url.startswith("postgres://"):
            url = "postgresql://" + url.removeprefix("postgres://")
        if url.startswith("postgresql://"):
            url = "postgresql+psycopg://" + url.removeprefix("postgresql://")
        return url

    @property
    def base_url(self) -> str:
        explicit = self.public_base_url.strip().rstrip("/")
        if explicit:
            return explicit
        hostname = os.getenv("RENDER_EXTERNAL_HOSTNAME", "").strip()
        if hostname:
            return f"https://{hostname}"
        return ""

    @property
    def bot_public_url(self) -> str:
        username = self.telegram_bot_username.strip().lstrip("@")
        return f"https://t.me/{username}" if username else ""

    @property
    def share_url(self) -> str:
        if not self.bot_public_url:
            return ""
        from urllib.parse import quote

        message = "Encontrei um bot que pesquisa promoções reais, compara preços e calcula o frete pelo CEP."
        return f"https://t.me/share/url?url={quote(self.bot_public_url)}&text={quote(message)}"

    def quota_for_plan(self, plan: str) -> int:
        mapping = {
            "basico": self.basic_monthly_quota,
            "pro": self.pro_monthly_quota,
            "premium": self.pro_monthly_quota,
            "empresarial": self.enterprise_monthly_quota,
            "admin": 0,
        }
        return mapping.get(plan, self.basic_monthly_quota)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
