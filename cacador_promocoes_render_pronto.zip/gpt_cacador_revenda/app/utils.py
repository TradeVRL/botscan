from __future__ import annotations

import re
from datetime import datetime
from zoneinfo import ZoneInfo


COMMAND_ALIASES = {
    "VARREDURA GERAL": "general",
    "VARREDURA AMAZON": "amazon",
    "VARREDURA FORNECEDORES": "suppliers",
    "VARREDURA PROMOÇÕES": "promotions",
    "VARREDURA PROMOCOES": "promotions",
    "ANALISAR PRODUTO": "product",
    "ANALISAR FORNECEDOR": "supplier_review",
    "COMPARAR MARKETPLACES": "marketplaces",
    "ATUALIZAR RELATÓRIO": "update",
    "ATUALIZAR RELATORIO": "update",
    "MODO EXPRESS": "express",
    "MODO PROFUNDO": "deep",
}

MODE_LABELS = {
    "general": "VARREDURA GERAL",
    "amazon": "VARREDURA AMAZON",
    "suppliers": "VARREDURA FORNECEDORES",
    "promotions": "VARREDURA PROMOÇÕES",
    "product": "ANALISAR PRODUTO",
    "supplier_review": "ANALISAR FORNECEDOR",
    "marketplaces": "COMPARAR MARKETPLACES",
    "update": "ATUALIZAR RELATÓRIO",
}


def normalize_text(value: str) -> str:
    value = re.sub(r"\s+", " ", value.strip())
    return value


def detect_research_command(text: str) -> tuple[str | None, str, str]:
    """Retorna (command, query, depth)."""
    normalized = normalize_text(text)
    upper = normalized.upper()
    depth = "express"

    if upper.startswith("MODO PROFUNDO"):
        depth = "deep"
        normalized = normalized[len("MODO PROFUNDO") :].lstrip(" :-\n")
        upper = normalized.upper()
    elif upper.startswith("MODO EXPRESS"):
        depth = "express"
        normalized = normalized[len("MODO EXPRESS") :].lstrip(" :-\n")
        upper = normalized.upper()

    for label, command in COMMAND_ALIASES.items():
        if command in {"express", "deep"}:
            continue
        if upper.startswith(label):
            query = normalized[len(label) :].lstrip(" :-\n")
            return command, query, depth
    return None, normalized, depth


def split_text(text: str, limit: int = 3900) -> list[str]:
    text = text.strip()
    if not text:
        return []
    chunks: list[str] = []
    remaining = text
    while len(remaining) > limit:
        cut = remaining.rfind("\n", 0, limit)
        if cut < int(limit * 0.6):
            cut = remaining.rfind(" ", 0, limit)
        if cut < int(limit * 0.6):
            cut = limit
        chunks.append(remaining[:cut].strip())
        remaining = remaining[cut:].strip()
    if remaining:
        chunks.append(remaining)
    return chunks


def local_timestamp(timezone_name: str) -> str:
    return datetime.now(ZoneInfo(timezone_name)).strftime("%d/%m/%Y às %H:%M")


def safe_filename(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "_", value)
    return cleaned.strip("_")[:80] or "relatorio"
